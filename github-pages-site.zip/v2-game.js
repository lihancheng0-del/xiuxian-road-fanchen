(function () {
  'use strict';
  const D = window.V2_DATA;
  const app = document.getElementById('app');
  const modalRoot = document.getElementById('modal-root');
  const fxRoot = document.getElementById('fx-root');
  const toastRoot = document.getElementById('toast-root');
  const DEBUG = new URLSearchParams(location.search).get('debug') === '1';
  const SEEDED = new URLSearchParams(location.search).get('seed');
  const clamp = (v,a,b) => Math.max(a,Math.min(b,Number(v)||0));
  const esc = (v='') => String(v).replace(/[&<>'"]/g,(m)=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
  const fmt = (v) => v > 0 ? `+${v}` : `${v}`;
  const attrName = (key) => D.ATTRS.find(a=>a.key===key)?.name || key;
  const byId = (arr,id) => arr.find(x=>x.id===id);

  function hashSeed(text) {
    let h = 2166136261 >>> 0;
    for (let i=0;i<text.length;i++) { h ^= text.charCodeAt(i); h = Math.imul(h,16777619); }
    return h >>> 0;
  }
  class SeededRng {
    constructor(seed,state) { this.seed=seed; this.state=state ?? hashSeed(seed); }
    next() { let t=this.state+=0x6D2B79F5;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296; }
    int(min,max) { return min+Math.floor(this.next()*(max-min+1)); }
    pick(arr) { return arr[Math.floor(this.next()*arr.length)]; }
    weighted(arr,weight=(x)=>x.weight||1) { let total=arr.reduce((n,x)=>n+Math.max(0,weight(x)),0),r=this.next()*total; for(const x of arr){r-=Math.max(0,weight(x));if(r<=0)return x;}return arr[arr.length-1]; }
  }
  function randomSeed() {
    const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const bytes=new Uint8Array(8); crypto.getRandomValues(bytes);
    return `${[0,1,2,3].map(i=>chars[bytes[i]%chars.length]).join('')}-${[4,5,6,7].map(i=>chars[bytes[i]%chars.length]).join('')}`;
  }
  function cleanSeed(v) { return String(v||'').toUpperCase().replace(/[^A-Z0-9-]/g,'').slice(0,12); }

  const SETTINGS_KEY='xiuxian-v2-settings';
  const settings=(()=>{try{return {...{music:true,sfx:true,volume:.36,motion:true},...JSON.parse(localStorage.getItem(SETTINGS_KEY)||'{}')}}catch{return {music:true,sfx:true,volume:.36,motion:true}}})();
  function saveSettings(){try{localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings))}catch{}}

  const AUDIO_FILES={
    home:'home-mountain',mortal:'mortal-years',assembly:'hundred-sects',sect:'sect-clouds',explore:'mystic-road',battle:'blade-storm',mystic:'ancient-secret',npc:'moon-companion',heart:'heart-demon',tribulation:'nine-thunders',death:'mortal-end',ascension:'ascension-gate'
  };
  class AudioDirector {
    constructor(){this.current=null;this.key='';this.unlocked=false;this.sfx={};}
    unlock(){if(this.unlocked)return;this.unlocked=true;if(settings.music)this.play(this.key||'home');}
    play(key){this.key=key;if(!this.unlocked||!settings.music)return;const file=AUDIO_FILES[key]||AUDIO_FILES.home;if(this.current?.dataset.file===file){this.current.play().catch(()=>{});return;}const next=new Audio(`assets/audio/bgm/${file}.wav`);next.loop=true;next.volume=0;next.preload='auto';next.dataset.file=file;next.addEventListener('error',()=>{}, {once:true});next.play().then(()=>{let step=0,old=this.current;this.current=next;const timer=setInterval(()=>{step++;next.volume=settings.volume*Math.min(1,step/12);if(old)old.volume=settings.volume*Math.max(0,1-step/12);if(step>=12){clearInterval(timer);old?.pause();}},80)}).catch(()=>{});}
    cue(name){if(!this.unlocked||!settings.sfx)return;const a=new Audio(`assets/audio/sfx/${name}.wav`);a.volume=Math.min(.75,settings.volume*1.7);a.play().catch(()=>{});}
    stop(){if(this.current){this.current.pause();this.current=null;}}
  }
  const audio=new AudioDirector();

  let ui={screen:'home',setupStep:'gender',seedInput:SEEDED||'',activeEvent:null,result:null,turnSummary:null,selectedSect:null,showChronicle:false,showHeaven:false,showBag:false,debugOpen:false};
  let state=null, rng=null;

  function emptyAttrs(){return Object.fromEntries(D.ATTRS.map(a=>[a.key,0]));}
  function emptyAffinity(){return {sword:0,blade:0,staff:0,spear:0,fist:0,focus:0,talisman:0,alchemy:0,forge:0,body:0,demon:0,wanderer:0};}
  function worldSchedule(r){return D.WORLD_EVENTS.map(w=>{const offset=r.int(w.min,w.max);return {...w,dueYear:10+offset,status:'countdown',visible:w.visible};});}
  function createState(seed){
    const r=new SeededRng(seed);
    const npcs=Object.fromEntries(D.NPCS.map(n=>[n.id,{...n,relation:0,status:'alive',memories:[],stage:0}]));
    const s={version:D.version,seed,rngState:r.state,phase:'setup',year:0,age:10,gender:'',name:'',attributes:emptyAttrs(),initialPoints:20,innateTags:[],silver:8,spiritStones:0,spiritualRoot:null,rootWeights:{jin:2,mu:2,shui:2,huo:2,tu:2,dual:1,triple:2,five:3,feng:.5,lei:.5,ice:.5,shadow:.25},physique:'凡骨',sect:null,path:null,weapon:null,realm:0,cultivation:0,lifespan:78,health:100,maxHealth:100,daoHeart:0,heartDemon:0,karma:0,sin:0,reputation:0,affinities:emptyAffinity(),inventory:[],skills:[],techniques:[],titles:['青石村人'],flags:{},futureTriggers:[],worldEvents:worldSchedule(r),npcs,chronicle:[],statistics:{events:0,success:0,fail:0,battles:0,kills:0,secrets:0,shops:0,breakthroughs:0},completedChains:{},recentChains:[],tension:{bad:0,good:0},currentTurn:{selected:[],completed:[],logs:[]},ending:null};
    s.rngState=r.state;return s;
  }
  function syncRng(){if(state)state.rngState=rng.state;}
  function startGame(seed){const clean=cleanSeed(seed)||randomSeed();state=createState(clean);rng=new SeededRng(clean,state.rngState);ui={...ui,screen:'setup',setupStep:'gender',seedInput:clean,activeEvent:null,result:null,turnSummary:null};audio.unlock();audio.play('home');render();}

  function topBar(){
    if(!state)return '';
    const realm=D.REALMS[state.realm]?.name||'凡躯';
    return `<header class="topbar"><button class="seal" data-act="home" aria-label="返回首页">修</button><div class="life-mark"><b>${esc(state.name||'无名')}</b><span>${state.age}岁 · ${realm}</span></div><button class="heaven-btn" data-act="heaven">天机</button><button class="icon-btn" data-act="bag" aria-label="行囊">囊</button><button class="icon-btn ${settings.music?'on':''}" data-act="music" aria-label="音乐">♫</button></header>`;
  }
  function bottomNav(){if(!state||['home','setup','ending'].includes(ui.screen))return '';return `<nav class="bottom-nav"><button data-act="chronicle">命书</button><button data-act="bag">行囊</button><button data-act="heaven">天道</button></nav>`;}
  function visual(path,glyph='道',title=''){return `<figure class="scene"><img src="${path}" alt="${esc(title)}" onerror="this.classList.add('missing')"><span class="scene-glyph">${glyph}</span></figure>`;}
  function toast(msg,type=''){const el=document.createElement('div');el.className=`toast ${type}`;el.textContent=msg;toastRoot.appendChild(el);setTimeout(()=>el.remove(),2600);}
  function rewardFx(notes,kind='fortune'){
    if(!settings.motion)return;const text=notes.find(n=>/获得|领悟|灵根|法宝|命格/.test(n))||notes[0]||'命数流转';
    fxRoot.innerHTML=`<div class="reward-fx ${kind}"><div class="halo"></div><div class="reward-orbit">${kind==='danger'?'伤':kind==='skill'?'法':kind==='artifact'?'宝':'福'}</div><b>${esc(text)}</b><i></i><i></i><i></i><i></i></div>`;setTimeout(()=>fxRoot.innerHTML='',1700);
  }
  function log(title,text,extra={}){state.chronicle.unshift({year:state.year,age:state.age,title,text,...extra});}
  function addUnique(arr,item){if(item&&!arr.includes(item)){arr.push(item);return true}return false;}
  function npcTitle(n){if(!n)return '道友';const rel=n.relation||0;if(rel>=65)return state.gender==='女'?'卿卿':'知己';if(rel>=35)return state.realm>2?'真人':'道友';if(rel<=-35)return '死敌';if(state.sect&&n.sect===byId(D.SECTS,state.sect)?.name)return state.gender==='女'?'师妹':'师弟';return state.realm>=4?'前辈':'道友';}
  function requirementOK(req){if(!req)return true;if(req.tag&&!state.innateTags.includes(req.tag))return false;if(req.flag&&!state.flags[req.flag])return false;if(req.item&&!state.inventory.includes(req.item))return false;if(req.attr&&state.attributes[req.attr]<(req.min||0))return false;if(req.npc&&state.npcs[req.npc]?.status!=='alive')return false;return true;}
  function riskChance(choice){
    const check=choice.effects?.check;if(!check)return 100;
    let val=0;
    if(check.mode==='highest')val=Math.max(...Object.values(state.attributes));
    else if(check.mode==='lowest')val=Math.min(...Object.values(state.attributes));
    else if(check.mode==='affinity')val=Math.max(...Object.values(state.affinities));
    else val=state.attributes[check.attr]||0;
    const support=(state.attributes.qiyun||0)*.45+(state.attributes.daoxin||0)*.2;
    const realmBonus=state.phase==='cultivation'?state.realm*1.4:0;
    return clamp(48+(val+support+realmBonus-(check.difficulty||10))*4,5,94);
  }
  function outcomeText(choice,success){
    if(success&&choice.successText)return choice.successText;
    if(!success&&choice.failText)return choice.failText;
    const e=success?(choice.effects||{}):(choice.failEffects||choice.effects||{});
    if(success){
      if(e.item)return `你依照“${choice.label}”行事，最终将「${e.item}」收入行囊。`;
      if(e.skill)return `你依照“${choice.label}”行事，灵光贯通，悟得《${e.skill}》。`;
      if(e.npc){const npc=state.npcs[e.npc.id];return `你依照“${choice.label}”行事，${npc?.name||'故人'}把这一刻记在了心里。`}
      if(e.lifespan>0)return `你依照“${choice.label}”行事，生机由枯转荣，寿数悄然延长。`;
      if(e.cultivation>0)return `你依照“${choice.label}”行事，把这场经历炼成了实打实的修为。`;
      if(e.health>0)return `你依照“${choice.label}”行事，旧伤渐平，气血重新充盈。`;
      if(e.karma>0)return `你依照“${choice.label}”行事，一段善因自此落入命书。`;
      if(e.sin>0)return `你依照“${choice.label}”行事，所得虽真，一缕业障也随之缠身。`;
      return `你完成了“${choice.label}”。眼前风波暂息，这个选择已经改变后续因果。`;
    }
    const check=e.check||choice.effects?.check;const cost=e.health<0?'受创负伤':e.cultivation<0?'折损修为':e.lifespan<0?'折损寿元':'付出了代价';
    return `你尝试“${choice.label}”，却低估了${check?.attr?attrName(check.attr):'其中凶险'}；局势陡然反转，你${cost}，只得记下这次教训。`;
  }
  function getRandomLegacyItem(kind){const pool=kind==='skill'?(D.LEGACY.SKILLS||[]):kind==='artifact'?(D.LEGACY.ARTIFACTS||[]):D.LEGACY.PILLS||[];return pool.length?rng.pick(pool).name:`无名${kind}`;}
  function applyLegacy(e,notes){
    if(e.xp){state.cultivation=Math.max(0,state.cultivation+e.xp);notes.push(`修为 ${fmt(e.xp)}`)}
    if(e.hp){state.health=clamp(state.health+e.hp,0,state.maxHealth);notes.push(`健康 ${fmt(e.hp)}`)}
    if(e.life){state.lifespan=Math.max(state.age+1,state.lifespan+e.life);notes.push(`寿元 ${fmt(e.life)}`)}
    if(e.demon){state.heartDemon=clamp(state.heartDemon+e.demon,0,120);notes.push(`心魔 ${fmt(e.demon)}`)}
    if(e.karma){state.sin=clamp(state.sin+e.karma,0,160);notes.push(`业障 ${fmt(e.karma)}`)}
    if(e.ally){state.reputation+=e.ally;notes.push(`人脉 ${fmt(e.ally)}`)}
    if(e.enemy){state.flags.enemies=(state.flags.enemies||0)+e.enemy;notes.push(`仇敌 ${fmt(e.enemy)}`)}
    if(e.attr){if(e.attr==='weakest'){const k=Object.keys(state.attributes).sort((a,b)=>state.attributes[a]-state.attributes[b])[0];state.attributes[k]++;notes.push(`${attrName(k)} +1`)}else Object.entries(e.attr).forEach(([k,v])=>{const nk=k==='fuyuan'?'qiyun':k==='meili'?'meili':k;state.attributes[nk]=(state.attributes[nk]||0)+v;notes.push(`${attrName(nk)} ${fmt(v)}`)})}
    if(e.skill){const name=e.skill==='random'||e.skill==='rare'?getRandomLegacyItem('skill'):e.skill;if(addUnique(state.skills,name)){notes.push(`领悟功法《${name}》`);audio.cue('spell')}}
    if(e.artifact){const name=e.artifact==='random'?getRandomLegacyItem('artifact'):e.artifact;if(addUnique(state.inventory,name))notes.push(`获得法宝「${name}」`)}
    if(e.pill){const name=e.pill==='random'||e.pill==='rare'?getRandomLegacyItem('pill'):e.pill;if(addUnique(state.inventory,name)){notes.push(`获得丹药「${name}」`);audio.cue('pill')}}
  }
  function applyEffects(e,success=true){
    const notes=[];if(!e)return notes;
    const value=(key)=>Number(e[key]||0);
    const direct=['gengu','wuxing','tipo','lingli','shenshi','daoxin','shenfa','meili','shafa','qiyun'];
    direct.forEach(k=>{if(e[k]){state.attributes[k]=Math.max(0,state.attributes[k]+e[k]);notes.push(`${attrName(k)} ${fmt(e[k])}`)}});
    if(e.allStat)direct.forEach(k=>state.attributes[k]+=e.allStat),notes.push(`十维属性 ${fmt(e.allStat)}`);
    if(e.silver){state.silver=Math.max(0,state.silver+e.silver);notes.push(`银两 ${fmt(e.silver)}`);if(e.silver>0)audio.cue('coins')}
    if(e.spiritStones){state.spiritStones=Math.max(0,state.spiritStones+e.spiritStones);notes.push(`灵石 ${fmt(e.spiritStones)}`);if(e.spiritStones>0)audio.cue('coins')}
    if(e.cultivation){state.cultivation=Math.max(0,state.cultivation+e.cultivation);notes.push(`修为 ${fmt(e.cultivation)}`)}
    if(e.health){let v=e.health;if(v<0&&state.inventory.includes('护心符'))v=Math.round(v*.8);state.health=clamp(state.health+v,0,state.maxHealth);notes.push(`健康 ${fmt(v)}`)}
    if(e.lifespan){state.lifespan=Math.max(state.age+1,state.lifespan+e.lifespan);notes.push(`寿元 ${fmt(e.lifespan)}`)}
    if(e.demon){state.heartDemon=clamp(state.heartDemon+e.demon,0,120);notes.push(`心魔 ${fmt(e.demon)}`);if(e.demon>0)audio.cue('heartbeat')}
    if(e.karma){state.karma=clamp(state.karma+e.karma,-80,160);notes.push(`因果 ${fmt(e.karma)}`)}
    if(e.sin){state.sin=clamp(state.sin+e.sin,0,180);notes.push(`业障 ${fmt(e.sin)}`)}
    if(e.reputation){state.reputation+=e.reputation;notes.push(`宗门声望 ${fmt(e.reputation)}`)}
    if(e.affinity)Object.entries(e.affinity).forEach(([k,v])=>{state.affinities[k]=(state.affinities[k]||0)+v;notes.push(`${affinityName(k)}亲和 ${fmt(v)}`)});
    if(e.rootHint)Object.entries(e.rootHint).forEach(([k,v])=>state.rootWeights[k]=(state.rootWeights[k]||0)+v);
    if(e.flags)(Array.isArray(e.flags)?e.flags:[e.flags]).forEach(f=>state.flags[f]=true);
    if(e.item&&addUnique(state.inventory,e.item))notes.push(`获得「${e.item}」`);
    if(e.removeItem){const i=state.inventory.indexOf(e.removeItem);if(i>=0){state.inventory.splice(i,1);notes.push(`失去「${e.removeItem}」`)}}
    if(e.skill&&addUnique(state.skills,e.skill)){notes.push(`领悟功法《${e.skill}》`);audio.cue('spell')}
    if(e.title&&addUnique(state.titles,e.title))notes.push(`获得称号「${e.title}」`);
    if(e.future){const due=e.future.year??(state.year+(e.future.yearOffset||10));state.futureTriggers.push({...e.future,dueYear:due});notes.push(`一桩因果已埋入未来`)}
    if(e.npc){const n=state.npcs[e.npc.id];if(n&&n.status==='alive'){const delta=e.npc.relation||0;n.relation=clamp(n.relation+delta,-100,100);n.memories.push({year:state.year,event:ui.activeEvent?.eventId,relation:delta});notes.push(`${n.name}好感 ${fmt(delta)}`);if(delta)audio.cue(delta>0?'relation-up':'relation-down')}}
    if(e.cost){audio.cue('buy');for(const [k,v] of Object.entries(e.cost)){if((state[k]||0)<v){notes.push(`${k==='spiritStones'?'灵石':'资源'}不足`);continue}state[k]-=v;notes.push(`${k==='spiritStones'?'灵石':k} -${v}`)}}
    if(e.requireCurrency){audio.cue('buy');for(const [k,v] of Object.entries(e.requireCurrency)){if(state[k]>=v){state[k]-=v;notes.push(`${k==='silver'?'银两':k} -${v}`)}else notes.push('钱财不足，未能兑现承诺')}}
    if(e.action==='revealRoot'){revealRoot(notes)}
    if(e.action==='scoreAssembly'){scoreAssembly(e.assemblySafe||0,notes)}
    if(e.action==='showInvites'){makeInvites(notes)}
    if(e.action==='merchantRelation'){const rel=state.npcs.shenwanshan.relation;if(state.flags.lentMerchant||rel>=18){state.spiritStones+=35;notes.push('二十两旧恩：灵石 +35');state.flags.vipMerchant=true}else notes.push('沈万山仍记得你，只是这份交情尚浅')}
    if(e.legacy)applyLegacy(e.legacy,notes);
    if(!success&&!e.authoredFail){const check=e.check;if(check){const severity=Math.max(4,Math.round((check.difficulty||10)*1.1));state.health=clamp(state.health-severity,0,state.maxHealth);notes.push(`判定失败：健康 -${severity}`);if(['daoxin','wuxing','shenshi'].includes(check.attr)){state.heartDemon=clamp(state.heartDemon+4,0,120);notes.push('心魔 +4')}}}
    syncRng();return notes;
  }
  function affinityName(k){return ({sword:'剑道',blade:'刀道',staff:'棍道',spear:'枪道',fist:'拳道',focus:'气法',talisman:'符箓',alchemy:'丹道',forge:'炼器',body:'体修',demon:'魔道',wanderer:'散修'})[k]||k;}
  function storyText(text){return String(text||'').replaceAll('{name}',state?.name||'无名').replaceAll('{sect}',byId(D.SECTS,state?.sect)?.name||'无门无派')}
  function chapterName(){if(state.realm<=2)return '第二章 · 仙门初修';if(state.realm<=4)return '第三章 · 大道争锋';if(state.realm<=6)return '第四章 · 问鼎长生';return '第五章 · 渡劫飞升'}
  function revealRoot(notes){
    const attr=state.attributes;state.rootWeights.jin+=attr.shafa*.18+state.affinities.sword*.25;state.rootWeights.mu+=attr.qiyun*.14+state.affinities.alchemy*.3;state.rootWeights.shui+=attr.daoxin*.16+state.affinities.focus*.25;state.rootWeights.huo+=attr.lingli*.14+state.affinities.blade*.25;state.rootWeights.tu+=attr.tipo*.18+state.affinities.body*.25;state.rootWeights.feng+=attr.shenfa*.2;state.rootWeights.lei+=state.flags.touchedThunder?4:0;state.rootWeights.ice+=state.flags.dragonScale?2:0;state.rootWeights.shadow+=state.sin*.08+state.affinities.demon*.25;
    const root=rng.weighted(D.ROOTS,x=>Math.max(.1,state.rootWeights[x.id]||.1));state.spiritualRoot=root.id;notes.push(`灵根显化：${root.name}`);if(root.rarity==='稀有'||root.rarity==='异数'){state.flags.rareRoot=true;audio.cue('rare-root');rewardFx([root.name],'skill')}
  }
  function scoreAssembly(safe,notes){
    const a=state.attributes,root=byId(D.ROOTS,state.spiritualRoot);const affinity=Math.max(...Object.values(state.affinities));let score=a.gengu*2+a.tipo*1.2+a.daoxin*1.4+a.lingli+affinity*1.8+Math.min(16,state.health/7)+safe;
    score+=(root?.rarity==='稀有'?14:root?.rarity==='良品'?8:root?.id==='five'?-8:3);score+=state.cultivation*1.5;score-=state.heartDemon*.5;score-=state.sin*.15;if(state.health<35)score-=14;
    state.flags.assemblyScore=Math.round(score);state.flags.assemblyReasons=[`根骨 ${a.gengu}`,`体魄 ${a.tipo}`,`${root?.name||'灵根未明'}`,`最高亲和 ${affinity}`,`身体 ${state.health}`];notes.push(`问仙总评：${Math.round(score)}分`);
  }
  function sectFit(sect){
    const mods=sect.mods||{};let fit=state.flags.assemblyScore||0;for(const k of Object.keys(mods))fit+=(state.attributes[k]||0)*mods[k]*1.4;
    const pref=({qingxuan:'sword',badao:'blade',lingtai:'staff',taixu:'focus',wanfa:'talisman',baicao:'alchemy',tiegum:'body',wuxiang:'demon',sanxiu:'wanderer'})[sect.id];fit+=(state.affinities[pref]||0)*3;if(sect.id==='wuxiang')fit+=state.sin*.5;if(sect.id==='sanxiu')fit+=state.flags.vowWanderer?22:0;if(sect.id==='qingxuan'&&state.spiritualRoot==='jin')fit+=8;return Math.round(fit);
  }
  function makeInvites(notes){
    const all=D.SECTS.map(s=>({...s,fit:sectFit(s)})).sort((a,b)=>b.fit-a.fit);let available=all.filter(s=>s.fit>=45);
    const doomed=(state.flags.assemblyScore||0)<38||state.health<=18||state.attributes.gengu===0&&state.cultivation===0;
    if(doomed)available=[];state.flags.invites=available.map(x=>x.id);state.flags.sectRanking=all.map(x=>({id:x.id,fit:x.fit}));notes.push(available.length?`${available.length}家仙门递来名帖`:'高台之上，无人开口');
  }
  function legacyChains(){
    return (D.LEGACY.EVENTS||[]).map(ev=>({eventId:`legacy-${ev.id}`,chainId:`legacy-${ev.key}`,title:ev.title,phase:'cultivation',yearRange:[20,999],weight:2,cooldown:3,unique:false,legacy:true,nodes:[{nodeId:'start',title:ev.title,image:legacyImage(ev.art),music:['sword','beast','storm'].includes(ev.art)?'battle':'explore',soundEffect:'choice',description:ev.desc,choices:ev.options.map(o=>({label:o.label,risk:o.safe?'稳妥':o.diff>=11?'绝境':o.diff>=8?'凶险':'冒险',effects:{check:o.safe?null:{attr:o.attr==='path'?(byId(D.PATHS,state?.path)?.attrs?.[0]||'wuxing'):o.attr==='fuyuan'?'qiyun':o.attr,difficulty:o.diff+5},legacy:o.success},failEffects:{legacy:o.fail,authoredFail:true,check:o.safe?null:{attr:o.attr==='path'?(byId(D.PATHS,state?.path)?.attrs?.[0]||'wuxing'):o.attr==='fuyuan'?'qiyun':o.attr,difficulty:o.diff+5}},successText:o.result?.success,failText:o.result?.fail}))}]}));
  }
  function legacyImage(art){return ({sword:'assets/scene-battle.webp',beast:'assets/scene-battle.webp',storm:'assets/images/scenes/blood-moon.webp',demon:'assets/images/scenes/heart-demon.webp',alchemy:'assets/images/scenes/alchemy-fire.webp',market:'assets/images/scenes/merchant-cart.webp',spirit:'assets/scene-mystic.webp'})[art]||'assets/scene-fortune.webp';}

  function getChain(id){return [...D.MORTAL_CHAINS,...D.CULTIVATION_CHAINS,...legacyChains()].find(c=>c.eventId===id||c.chainId===id);}
  function openChain(id){const c=getChain(id);if(!c){toast('这段因果暂时无法显现','bad');return}ui.activeEvent={eventId:c.eventId,nodeId:c.nodes[0].nodeId};ui.result=null;ui.screen='event';audio.play(c.nodes[0].music||phaseMusic());audio.cue(c.nodes[0].soundEffect||(['battle','tribulation'].includes(c.nodes[0].music)?'sword':'page'));render();}
  function activeChain(){return getChain(ui.activeEvent?.eventId)}
  function activeNode(){const c=activeChain();return c?.nodes.find(n=>n.nodeId===ui.activeEvent?.nodeId)}
  function resolveChoice(index){
    if(ui.result||state.ending)return;audio.unlock();const c=activeChain(),n=activeNode(),ch=n?.choices[index];if(!ch||!requirementOK(ch.requirement))return;
    if(ch.effects?.cost&&Object.entries(ch.effects.cost).some(([k,v])=>(state[k]||0)<v)){toast('手中资财不足','bad');return}
    let chance=riskChance(ch),success=chance>=100||rng.next()<chance/100;syncRng();
    const fallbackFail=()=>{const src=ch.effects||{},out={check:src.check};for(const k of ['health','lifespan','silver','spiritStones','cultivation','karma'])if(Number(src[k])<0)out[k]=src[k];for(const k of ['demon','sin'])if(Number(src[k])>0)out[k]=src[k];return out};
    const effects=success?ch.effects:(ch.failEffects||fallbackFail());const notes=applyEffects(effects,success);
    const narrative=storyText(outcomeText(ch,success));state.statistics.events++;state.statistics[success?'success':'fail']++;if(['battle','tribulation'].includes(n.music))state.statistics.battles++;
    if(success){state.tension.good++;state.tension.bad=0}else{state.tension.bad++;state.tension.good=0}
    log(c.title,narrative,{choice:ch.label,success,notes:[...notes]});state.currentTurn.logs.push(`${c.title}：${narrative}（${notes.join('，')||'命数无改'}）`);
    ui.result={success,label:ch.label,narrative,notes,chance,nextNode:ch.nextNode};audio.cue(success?(notes.some(x=>x.includes('获得'))?'treasure':'success'):'injury');
    if(notes.some(x=>x.includes('功法')))rewardFx(notes,'skill');else if(notes.some(x=>x.includes('法宝')||x.includes('获得「')))rewardFx(notes,'artifact');else if(notes.some(x=>x.includes('气运')||x.includes('灵根')))rewardFx(notes,'fortune');else if(!success)rewardFx(notes,'danger');
    checkDeath();render();
  }
  function continueResult(){
    if(!ui.result||state.ending)return;const next=ui.result.nextNode;ui.result=null;
    if(next){const c=activeChain();if(!c.nodes.some(n=>n.nodeId===next)){toast('因果节点缺失，已安全结束本事件','bad');finishChain();return}ui.activeEvent.nodeId=next;audio.play(activeNode().music||phaseMusic());audio.cue(activeNode().soundEffect||'page');render();return}
    finishChain();
  }
  function finishChain(){
    const c=activeChain();if(c){state.completedChains[c.chainId]=(state.completedChains[c.chainId]||0)+1;state.recentChains.unshift({id:c.chainId,year:state.year});state.recentChains=state.recentChains.slice(0,12);const world=state.worldEvents.find(w=>w.chain===c.chainId&&w.status==='active');if(world)world.status='done'}
    ui.activeEvent=null;ui.result=null;
    if(state.phase==='mortal'){
      if(state.year<9){ui.turnSummary={title:`第 ${state.year+1} 年 · 岁月小结`,text:state.currentTurn.logs.slice(),next:'year'};ui.screen='summary'}
      else if(state.year===9){ui.screen='assembly-transition'}
    }else if(state.phase==='assembly'){
      if(state.flags.invites){ui.screen='sect-choice'}else ui.screen='assembly-transition';
    }else{
      if(c&&state.currentTurn.selected.includes(c.eventId)&&!state.currentTurn.completed.includes(c.eventId))state.currentTurn.completed.push(c.eventId);ui.screen='decade';audio.play('sect');
    }
    checkDeath();render();
  }
  function nextMortalYear(){state.year++;state.age++;state.currentTurn={selected:[],completed:[],logs:[]};ui.turnSummary=null;if(state.year===9){state.phase='assembly';ui.screen='assembly-transition';audio.play('assembly');render()}else{state.phase='mortal';openChain(D.MORTAL_CHAINS.find(c=>c.phase==='mortal'&&c.yearRange[0]===state.year+1)?.eventId||'mortal_home')}}
  function enterMortal(){state.phase='mortal';state.year=0;state.age=10;state.currentTurn={selected:[],completed:[],logs:[]};log('此生落笔',`${state.name}生于大周青石村，命数 ${state.seed}。`);audio.play('mortal');openChain('mortal_home')}
  function decideInnate(){state.innateTags=[];for(const t of D.INNATE_TAGS){if(state.attributes[t.attr]>=t.at)addUnique(state.innateTags,t.name)}if(!state.innateTags.length)addUnique(state.innateTags,'白身问道');if(state.attributes.tipo===0)addUnique(state.innateTags,'肉身孱弱');if(state.attributes.daoxin===0)addUnique(state.innateTags,'心湖无锚');if(state.attributes.meili===0)addUnique(state.innateTags,'孤命');}
  function chooseSect(id){if(!(state.flags.invites||[]).includes(id))return;state.sect=id;if(id==='qingxuan'){state.npcs.luchenzhou.relation=5;state.npcs.luchenzhou.memories.push({year:state.year,event:'收入门下'})}ui.selectedSect=id;ui.screen='path-choice';render()}
  function acceptHiddenRescue(){state.sect='sanxiu';state.flags.hiddenRescue=true;state.flags.invites=['sanxiu'];log('因果回响',`第八年，你曾在桥下帮助莫问尘。今日百宗不收，他却说：“他们不要你，我要。”`);ui.screen='path-choice';render()}
  function rejectToEnding(){showEnding('仙途断绝','九座高台始终无人开口。你站在人群外，看着飞舟一艘艘消失在云海。那一年，你二十岁。此后六十余载，再未见过山巅那一日的仙人。','mortal')}
  function choosePath(id){const p=byId(D.PATHS,id);if(!p)return;state.path=id;state.weapon=p.name.replace('修','');state.skills.push(p.skill);state.affinities[p.affinity]=(state.affinities[p.affinity]||0)+2;state.spiritStones=12;state.lifespan+=28;state.realm=1;state.cultivation=10;state.phase='cultivation';state.year=10;state.age=20;state.titles.push(`${byId(D.SECTS,state.sect)?.name||'无门'}弟子`);log('拜入仙门',`${state.name}拜入${byId(D.SECTS,state.sect)?.name||'无门传承'}，主修${p.name}，得《${p.skill}》。`);prepareDecade();}
  function availableChains(){
    const due=state.worldEvents.filter(w=>w.status==='countdown'&&w.dueYear<=state.year);const dueF=state.futureTriggers.filter(f=>f.dueYear<=state.year&&!f.done);let pool=[...D.CULTIVATION_CHAINS.filter(c=>c.phase==='cultivation'),...legacyChains()];
    pool=pool.filter(c=>state.age>=c.yearRange[0]&&state.age<=c.yearRange[1]).filter(c=>!c.unique||!state.completedChains[c.chainId]).filter(c=>!state.recentChains.some(r=>r.id===c.chainId&&state.year-r.year<(c.cooldown||0)*10));
    const picks=[];if(due.length){const w=due[0];const c=getChain(w.chain);if(c)picks.push(c);w.status='active'}else if(dueF.length){const f=dueF[0],scheduledWorld=state.worldEvents.find(w=>w.id===f.eventId);const c=getChain(f.eventId)||getChain(scheduledWorld?.chain);if(c){picks.push(c);if(scheduledWorld)scheduledWorld.status='active'}f.done=true}
    while(picks.length<3&&pool.length){let pick=rng.weighted(pool,c=>{let weight=c.weight||1;if(state.tension.bad>=3&&['healing_years','companion_moon','merchant_return'].includes(c.chainId))weight*=3;if(state.tension.good>=3&&['blood_moon','heart_demon','sect_tournament'].includes(c.chainId))weight*=2;return weight});if(!pick)break;picks.push(pick);pool=pool.filter(c=>c.eventId!==pick.eventId)}
    if(!picks.length)picks.push(getChain('fallback'));syncRng();return picks;
  }
  function prepareDecade(){state.currentTurn={selected:availableChains().map(c=>c.eventId),completed:[],logs:[]};ui.screen='decade';ui.turnSummary=null;audio.play('sect');render()}
  function endDecade(){
    if(state.currentTurn.completed.length<state.currentTurn.selected.length){toast('三桩主要因缘尚未尽数了结','bad');return}
    const oldAge=state.age,gain=Math.max(18,Math.round((state.attributes.gengu+state.attributes.lingli+state.attributes.wuxing)*1.25+state.realm*12+20));state.cultivation+=gain;state.health=clamp(state.health+8+state.attributes.tipo,0,state.maxHealth);state.heartDemon=clamp(state.heartDemon-Math.max(2,Math.floor(state.attributes.daoxin/3)),0,120);state.year+=10;state.age+=10;
    state.npcs&&Object.values(state.npcs).forEach(n=>advanceNpc(n));
    ui.turnSummary={title:`${oldAge}—${state.age}岁 · 十年过场`,text:[...state.currentTurn.logs,`闭关吐纳：修为 +${gain}`,`天下大事的倒计时又少了十年。`],next:'decade'};ui.screen='summary';checkDeath();render();
  }
  function advanceNpc(n){if(n.status!=='alive')return;n.age+=10;const age=n.age;if(age>=40&&n.stage<1){n.stage=1;n.realm=n.realm==='凡人'?'炼气':'筑基'}if(age>=80&&n.stage<2){n.stage=2;n.realm='金丹'}if(age>=160&&n.stage<3){n.stage=3;n.realm='元婴'}if(n.relation<-65&&rng.next()<.08){n.status='enemy'}if(age>420&&rng.next()<.05){n.status='dead';n.memories.push({year:state.year,event:'寿尽'})}syncRng()}
  function continueAfterSummary(){if(ui.turnSummary?.next==='year')nextMortalYear();else{ui.turnSummary=null;prepareDecade()}}
  function canBreak(){return state.phase==='cultivation'&&state.realm<D.REALMS.length-1&&state.cultivation>=D.REALMS[state.realm].need}
  function breakthrough(){
    if(!canBreak())return;const final=state.realm===8;if(final){tribulation();return}const need=D.REALMS[state.realm].need;let chance=55+state.attributes.gengu*2+state.attributes.daoxin*1.6+state.attributes.qiyun*.8-state.heartDemon*.45-state.sin*.12+state.realm*-2;chance=clamp(chance,12,90);const ok=rng.next()<chance/100;syncRng();state.cultivation-=ok?need:Math.round(need*.6);
    if(ok){state.realm++;const realm=D.REALMS[state.realm];state.lifespan+=realm.life||0;state.maxHealth+=8+state.attributes.tipo;state.health=Math.min(state.maxHealth,state.health+30);state.statistics.breakthroughs++;const path=byId(D.PATHS,state.path)?.name||'修士';if(state.realm===3)addUnique(state.titles,`${path.replace('修','')}丹真人`);if(state.realm===5)addUnique(state.titles,`${path.replace('修','')}道真君`);if(state.realm===7)addUnique(state.titles,`${path.replace('修','')}尊`);log('境界突破',`${state.name}破境入${realm.name}，寿元延展。`,{notes:[`寿元 +${realm.life||0}`]});audio.cue('breakthrough');rewardFx([`突破至${realm.name}`],'skill');toast(`破境成功 · ${realm.name}`,'good')}
    else{const dmg=10+state.realm*3,addedDemon=6+state.realm;state.health-=dmg;state.heartDemon+=addedDemon;log('突破失败',`灵力逆冲，经脉受损；六成破境修为散去，但余下积累仍在。准备不足不是一句运气不好。`,{notes:[`修为 -${Math.round(need*.6)}`,`健康 -${dmg}`,`心魔 +${addedDemon}`]});audio.cue('break-fail');rewardFx([`突破失败 · 健康 -${dmg}`],'danger')}
    checkDeath();render();
  }
  function tribulation(){
    state.phase='tribulation';audio.play('tribulation');const prep=(state.attributes.daoxin*2+state.attributes.tipo+state.attributes.qiyun+state.skills.length*2+state.inventory.filter(x=>/劫|雷|登仙|仙器/.test(x)).length*8)-state.heartDemon-state.sin*.45;const chance=clamp(2+prep*.55,2,42);const roll=rng.next()*100;syncRng();
    if(roll<chance){state.realm=9;showEnding('白日飞升','九重雷海尽碎，天门在你剑前、拳下或道心中开启。你回望此界，所有旧因果化作一线金光。','ascension')}
    else if(prep>28&&rng.next()<.38){showEnding('兵解散仙','肉身毁于最后一道雷劫，元神却借法宝遁出。你未能飞升，但世间从此多了一位不受天门册封的散仙。','secondary')}
    else{state.health=0;showEnding('九重天劫 · 身陨','最后一道雷光穿透道基。直接死因是九重天劫；根本隐患来自不足的道心、旧伤、心魔或未了业障。','death')}
  }
  function checkDeath(){if(!state||state.ending)return false;if(state.health<=0){if(state.inventory.includes('替死傀儡')){state.inventory.splice(state.inventory.indexOf('替死傀儡'),1);state.health=1;toast('替死傀儡碎裂，替你承下一死','good');return false}showEnding('战死道消','健康归零，经脉与神魂一同断绝。命书列出了造成这场死亡的最后三次选择。','death');return true}if(state.heartDemon>=100){showEnding('走火入魔','心魔吞没最后一丝清明。每一次强求、逃避与魔功反噬都在此刻回响。','death');return true}if(state.age>=state.lifespan){showEnding('寿元耗尽','一次寻常吐纳之后，你没有再睁眼。大道未成，岁月先至。','death');return true}if(state.sin>=150){showEnding('因果焚身','被你压下的因果同时找上门来，道基在业火中崩解。','death');return true}return false}
  function showEnding(title,desc,type){if(state.ending)return;state.ending={title,desc,type,age:state.age};state.phase='ending';ui.screen='ending';audio.play(type==='ascension'?'ascension':type==='mortal'?'death':'death');audio.cue(type==='ascension'?'ascension':'death');log('此生结局',title,{notes:[desc]});render()}

  function phaseMusic(){if(state.phase==='mortal')return'mortal';if(state.phase==='assembly')return'assembly';if(state.phase==='tribulation')return'tribulation';return'sect'}
  function riskDetail(choice){const chance=riskChance(choice);const know=(state?.attributes.shenshi||0)+(state?.attributes.wuxing||0)>=12||DEBUG;let detail=choice.effects?.check?.attr?attrName(choice.effects.check.attr):'';if(know&&chance<100)detail+=` · 约 ${Math.floor(chance/10)*10}%`;return detail}
  function homeScreen(){audio.play('home');return `<section class="home-screen">${visual('assets/hero.webp','道','云海仙山')}<div class="home-copy"><p class="eyebrow">人生修仙 Roguelike · V2</p><h1>修仙之路</h1><h2>凡尘问道</h2><p>十岁起于柴门，二十岁问仙门。命数相同，选择不同，此生便不同。</p><button class="primary" data-act="start">开始此生</button><button class="text-btn" data-act="seed-open">输入命数 · 同命挑战</button><small>单机 · 无登录 · 不保存本局进度</small></div>${ui.seedInput!==''&&ui.screen==='seed'?seedPanel():''}</section>`}
  function seedPanel(){return `<div class="overlay-card"><button class="close" data-act="seed-close">×</button><p class="eyebrow">同命挑战</p><h3>输入朋友的命数</h3><input id="seed-input" maxlength="12" autocomplete="off" value="${esc(ui.seedInput)}" placeholder="例如 Q7X9-3KTA"><p>相同命数与相同选择会得到尽可能一致的世界。</p><button class="primary" data-act="seed-start">以此命数开始</button></div>`}
  function setupScreen(){
    let body='';
    if(ui.setupStep==='gender')body=`<p class="eyebrow">落笔之前</p><h1>此身为何？</h1><p>性别只改变立绘、称谓与部分叙事，不改变路线强度。</p><div class="gender-grid"><button data-act="gender" data-value="男">${visual('assets/images/characters/protagonist-male.webp','男','男性主角')}<b>男</b></button><button data-act="gender" data-value="女">${visual('assets/images/characters/protagonist-female.webp','女','女性主角')}<b>女</b></button></div>`;
    if(ui.setupStep==='name')body=`<p class="eyebrow">命书第一页</p><h1>此身何名？</h1><input id="name-input" class="name-input" maxlength="16" autocomplete="off" value="${esc(state.name)}" placeholder="输入姓名"><div class="row"><button class="secondary" data-act="random-name">随机姓名</button><button class="primary" data-act="name-next">写入命书</button></div><button class="text-btn" data-act="setup-back">返回</button>`;
    if(ui.setupStep==='attrs'){const used=Object.values(state.attributes).reduce((a,b)=>a+b,0),left=20-used;body=`<p class="eyebrow">白身 · 初始属性</p><h1>二十点命数，如何落下？</h1><div class="points-left ${left===0?'done':''}">剩余 <b>${left}</b> 点</div><div class="attr-editor">${D.ATTRS.map(a=>`<div class="attr-row"><span class="attr-icon">${a.icon}</span><div><b>${a.name}</b><small>${a.desc}</small></div><button data-act="attr-minus" data-key="${a.key}">−</button><strong>${state.attributes[a.key]}</strong><button data-act="attr-plus" data-key="${a.key}">＋</button><button class="all-btn" data-act="attr-all" data-key="${a.key}">全投</button></div>`).join('')}</div><div class="setup-actions"><button class="secondary" data-act="attr-reset">重置全部</button><button class="primary" data-act="attrs-confirm" ${left!==0?'disabled':''}>确认命格</button></div>`}
    if(ui.setupStep==='tags')body=`<p class="eyebrow">先天命格</p><h1>${state.innateTags.map(esc).join(' · ')}</h1><div class="tag-list">${state.innateTags.map(n=>{const t=D.INNATE_TAGS.find(x=>x.name===n);return `<article><b>${esc(n)}</b><p>${esc(t?.desc||'没有天赐异能，只有二十点亲手写下的命数。')}</p></article>`}).join('')}</div><p>极端命格会打开特殊道路，也会让无人照看的短板变得致命。</p><button class="primary" data-act="enter-mortal">凡尘问道 · 第一年度</button>`;
    return `<section class="setup-screen"><div class="paper-panel">${body}<footer>命数 ${esc(state.seed)}</footer></div></section>`
  }
  function statsStrip(){const realm=D.REALMS[state.realm]?.name||'凡躯';return `<section class="stats-strip"><span><i>龄</i><b>${state.age}/${state.lifespan}</b></span><span><i>境</i><b>${realm}</b></span><span><i>修</i><b>${state.cultivation}</b></span><span><i>命</i><b>${state.health}</b></span><span><i>${state.phase==='mortal'?'银':'石'}</i><b>${state.phase==='mortal'?state.silver:state.spiritStones}</b></span></section>`}
  function eventScreen(){const c=activeChain(),n=activeNode();if(!c||!n)return `<section class="paper-panel"><h2>因果断裂</h2><button data-act="safe-return">返回命书</button></section>`;const progress=`${c.nodes.findIndex(x=>x.nodeId===n.nodeId)+1}/${c.nodes.length}`;return `<section class="game-screen">${statsStrip()}<article class="event-card">${visual(n.image,n.music==='battle'?'战':state.phase==='mortal'?'尘':'缘',n.title)}<div class="event-body"><div class="event-meta"><span>${state.phase==='mortal'?`凡尘第 ${state.year+1} 年`:`${state.age}岁 · ${D.REALMS[state.realm].name}`}</span><span>${progress}</span></div><p class="eyebrow">${state.phase==='assembly'?'百宗问仙大会':c.legacy?'旧版因缘 · 完整保留':'命运事件链'}</p><h1>${esc(n.title)}</h1><p class="event-desc">${esc(storyText(n.description))}</p>${ui.result?resultPanel():`<div class="choices">${n.choices.map((ch,i)=>requirementOK(ch.requirement)?`<button data-act="choice" data-index="${i}"><span class="choice-seal">${'甲乙丙丁'[i]}</span><span><b>${esc(ch.label)}</b><small>${esc(ch.risk)}${riskDetail(ch)?` · ${esc(riskDetail(ch))}`:''}</small></span><em>›</em></button>`:'').join('')}</div>`}</div></article></section>`}
  function resultPanel(){const r=ui.result;return `<section class="result-panel ${r.success?'success':'fail'}"><div class="result-title"><span>${r.success?'吉':'凶'}</span><div><small>${r.success?'因缘有成':'一步踏错'}</small><h3>${esc(r.label)}</h3></div></div><p class="result-narrative">${esc(r.narrative)}</p><ul>${r.notes.map(n=>`<li>${esc(n)}</li>`).join('')||'<li>命数未有明显改变</li>'}</ul>${r.chance<100?`<small>本次判定：${Math.round(r.chance)}%</small>`:''}<button class="primary" data-act="continue-result">${r.nextNode?'循因果继续':'收起此页命书'}</button></section>`}
  function assemblyTransition(){return `<section class="assembly-screen">${visual('assets/images/scenes/flying-boats.webp','仙','百宗飞舟')}<div class="paper-panel"><p class="eyebrow">第十年 · 今年开启</p><h1>百宗问仙大会</h1><p>十年凡尘到此结算。灵根、根骨、修为、武器亲和、旧伤与旧日因果，都将成为高台上那一眼的分量。</p><button class="primary" data-act="assembly-enter">随万人登山</button></div></section>`}
  function sectChoice(){const invited=state.flags.invites||[],ranking=state.flags.sectRanking||[];if(!invited.length){const rescue=(state.flags.helpedTaoist||state.flags.vowWanderer)&&state.npcs.mowenchen.relation>=12;return `<section class="game-screen">${visual('assets/images/scenes/mortal-elimination.webp','凡','仙途断绝')}<div class="paper-panel verdict"><p class="eyebrow">仙门裁定</p><h1>无人收录</h1><ul>${(state.flags.assemblyReasons||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul><p>这不是一次纯粹的坏运气：根基、旧伤与十年选择共同把你留在了高台之外。</p>${rescue?`<div class="causal-echo"><b>因果回响</b><p>第八年，桥下那位落魄老道从人群后走来：“他们不要你，我要。”</p></div><button class="primary" data-act="hidden-rescue">拜入残缺散修传承</button>`:''}<button class="secondary" data-act="mortal-ending">接受凡人一生</button></div></section>`}
    return `<section class="game-screen">${statsStrip()}${visual('assets/images/scenes/sect-assembly.webp','仙','仙门邀请')}<div class="paper-panel"><p class="eyebrow">仙门裁定 · ${byId(D.ROOTS,state.spiritualRoot)?.name}</p><h1>${invited.length}家仙门递来名帖</h1><div class="sect-list">${ranking.map(x=>{const s=byId(D.SECTS,x.id),ok=invited.includes(x.id),stars=clamp(Math.round(x.fit/24),1,5);return `<button data-act="sect" data-value="${s.id}" ${ok?'':'disabled'}><span class="sect-sigil">${s.sigil}</span><span><b>${esc(s.name)}</b><small>${'★'.repeat(stars)}${'☆'.repeat(5-stars)} · ${ok?s.desc:'资质未达本宗门槛'}</small></span></button>`}).join('')}</div></div></section>`}
  function pathChoice(){const top=Object.entries(state.affinities).sort((a,b)=>b[1]-a[1]).slice(0,3);return `<section class="game-screen">${visual('assets/images/scenes/sect-gate.webp','道','择定道途')}<div class="paper-panel"><p class="eyebrow">拜入 ${esc(byId(D.SECTS,state.sect)?.name||'散修传承')}</p><h1>正式择定修行方向</h1><p>十年亲和：${top.map(([k,v])=>`${affinityName(k)} ${v}`).join(' · ')}。推荐不等于限制，你仍可逆天改命。</p><div class="path-grid">${D.PATHS.map(p=>`<button data-act="path" data-value="${p.id}" class="${top[0]?.[0]===p.affinity?'recommended':''}"><span>${p.icon}</span><b>${p.name}</b><small>${p.desc}</small></button>`).join('')}</div></div></section>`}
  function decadeScreen(){const selected=state.currentTurn.selected.map(getChain).filter(Boolean);const done=state.currentTurn.completed;const due=state.worldEvents.filter(w=>w.status==='countdown').sort((a,b)=>a.dueYear-b.dueYear)[0];const conclusions=[];if(state.realm>=7&&state.sin>=80&&state.skills.includes('血海魔功'))conclusions.push(`<button class="break-btn" data-act="claim-demon">万魔俯首 · 立魔道至尊</button>`);if(state.realm>=6&&state.reputation>=25&&state.age>=180)conclusions.push(`<button class="break-btn" data-act="claim-ancestor">开宗立派 · 成一方老祖</button>`);if(state.realm>=5&&state.karma>=35)conclusions.push(`<button class="break-btn" data-act="claim-guardian">止步人间 · 守一方众生</button>`);if(state.realm>=7&&state.flags.jadeComplete)conclusions.push(`<button class="break-btn" data-act="claim-jade">合上残玉 · 继上古道统</button>`);return `<section class="game-screen">${statsStrip()}<div class="chapter-hero">${visual('assets/images/scenes/sect-gate.webp','修','仙门十年')}<div><p class="eyebrow">${chapterName()} · 每回合十年</p><h1>${state.age}岁 · ${D.REALMS[state.realm].name}</h1><p>三桩主要因缘可自行决定处理顺序。全部了结后，才能结束这十年。</p></div></div><div class="paper-panel decade-panel">${due?`<div class="omen-line"><b>天下大事</b><span>${esc(due.title)} · ${Math.max(0,due.dueYear-state.year)}年后</span></div>`:''}<div class="event-deck">${selected.map((c,i)=>`<button data-act="open-turn-event" data-value="${c.eventId}" class="${done.includes(c.eventId)?'done':''}" ${done.includes(c.eventId)?'disabled':''}><span>${i+1}</span><div><small>${c.phase==='world'?'世界大事件':c.legacy?'旧版因缘':'十年事件链'}</small><b>${esc(c.title)}</b><em>${done.includes(c.eventId)?'已了结':`${c.nodes.length}层因果`}</em></div></button>`).join('')}</div><div class="progress-text">已完成 ${done.length} / ${selected.length}</div>${canBreak()?`<button class="break-btn" data-act="breakthrough">修为已满 · 尝试突破 ${D.REALMS[state.realm+1]?.name||'天门'}</button>`:''}${conclusions.join('')}<button class="primary" data-act="end-decade" ${done.length<selected.length?'disabled':''}>结束这十年</button></div></section>`}
  function summaryScreen(){return `<section class="summary-screen">${visual(state.phase==='mortal'?'assets/images/scenes/village-dawn.webp':'assets/images/scenes/mystic-realm.webp','年',ui.turnSummary.title)}<div class="paper-panel"><p class="eyebrow">岁月过场</p><h1>${esc(ui.turnSummary.title)}</h1><ol class="summary-list">${ui.turnSummary.text.map(x=>`<li>${esc(x)}</li>`).join('')}</ol><button class="primary" data-act="summary-next">${ui.turnSummary.next==='year'?'走入下一年':'再启一个十年'}</button></div></section>`}
  function endingScreen(){const e=state.ending;const image=e.type==='ascension'?'assets/images/scenes/ascension.webp':e.type==='mortal'?'assets/images/scenes/mortal-elimination.webp':'assets/images/scenes/heart-demon.webp';return `<section class="ending-screen">${visual(image,e.type==='ascension'?'仙':'终',e.title)}<div class="paper-panel"><p class="eyebrow">此生命书 · ${esc(state.seed)}</p><div class="ending-witness"><img src="assets/images/characters/tianyandaojun.webp" alt="天衍道君"><small>天衍道君执天秤，为此生落下最后一笔。</small></div><h1>${esc(e.title)}</h1><p>${esc(e.desc)}</p><div class="ending-stats"><span>享年 <b>${state.age}</b></span><span>境界 <b>${D.REALMS[state.realm]?.name}</b></span><span>称号 <b>${esc(state.titles.at(-1)||'无名')}</b></span><span>宗门 <b>${esc(byId(D.SECTS,state.sect)?.name||'无门')}</b></span><span>道侣 <b>${state.flags.partnerShen?'沈清霜':'无'}</b></span><span>故人 <b>${Object.values(state.npcs).filter(n=>n.relation>=20).length}</b></span></div><div class="ending-actions"><button class="primary" data-act="share">生成此生道途卡</button><button class="secondary" data-act="copy-seed">复制命数</button><button class="text-btn" data-act="restart">再活一世</button></div><canvas id="share-canvas" width="1080" height="1440" hidden></canvas></div></section>`}
  function chronicleModal(){return `<div class="modal-backdrop" data-act="modal-close"><section class="drawer" data-stop><button class="close" data-act="modal-close">×</button><p class="eyebrow">修仙录</p><h2>${esc(state.name)} · ${esc(state.titles.at(-1))}</h2><div class="chronicle">${state.chronicle.map(x=>`<article><time>${x.age}岁</time><div><b>${esc(x.title)}</b><p>${esc(x.text)}</p>${x.notes?.length?`<small>${x.notes.map(esc).join(' · ')}</small>`:''}</div></article>`).join('')}</div></section></div>`}
  function heavenModal(){const events=state.worldEvents.filter(w=>w.visible||state.flags.worldIntel);return `<div class="modal-backdrop" data-act="modal-close"><section class="drawer" data-stop><button class="close" data-act="modal-close">×</button><p class="eyebrow">天机 / 天下大事</p><h2>${state.phase==='mortal'?`百宗问仙大会 · ${state.year>=9?'今年开启':9-state.year+'年后'}`:'此界仍在运转'}</h2><div class="world-list">${events.map(w=>`<article><img src="${w.image}" alt=""><div><b>${esc(w.title)}</b><p>${w.status==='done'?'已经落幕':w.dueYear<=state.year?'正在发生':`${w.dueYear-state.year}年后`}</p></div></article>`).join('')}</div><footer>命数 ${esc(state.seed)}</footer></section></div>`}
  function bagModal(){const npcList=Object.values(state.npcs).filter(n=>n.relation!==0||n.memories.length);return `<div class="modal-backdrop" data-act="modal-close"><section class="drawer" data-stop><button class="close" data-act="modal-close">×</button><p class="eyebrow">行囊与故人</p><h2>声画设置</h2><div class="setting-row"><button data-act="music">背景音乐 ${settings.music?'开':'关'}</button><button data-act="sfx">音效 ${settings.sfx?'开':'关'}</button><button data-act="motion">动态效果 ${settings.motion?'开':'关'}</button></div><div class="setting-row"><button data-act="volume-down">音量 −</button><span>${Math.round(settings.volume*100)}%</span><button data-act="volume-up">音量 ＋</button></div><h2>所学功法</h2><div class="chips">${state.skills.map(x=>`<span>《${esc(x)}》</span>`).join('')||'<small>尚未习得功法</small>'}</div><h2>法宝丹药</h2><div class="chips">${state.inventory.map(x=>`<span>${esc(x)}</span>`).join('')||'<small>两袖清风</small>'}</div><h2>十维命数</h2><div class="mini-attrs">${D.ATTRS.map(a=>`<span>${a.name}<b>${state.attributes[a.key]}</b></span>`).join('')}</div><h2>故人</h2><div class="npc-list">${npcList.map(n=>`<article><img src="${n.portrait}" alt="${esc(n.name)}"><div><b>${esc(n.name)} · ${esc(npcTitle(n))}</b><small>${esc(n.realm)} · 好感 ${n.relation} · ${n.status==='alive'?'尚在人间':n.status}</small><p>${esc(n.intro)}</p></div></article>`).join('')||'<small>此生尚无故人</small>'}</div></section></div>`}
  function debugPanel(){if(!DEBUG||!state)return'';return `<aside class="debug-panel ${ui.debugOpen?'open':''}"><button data-act="debug-toggle">调</button>${ui.debugOpen?`<b>V2 DEBUG</b><small>seed ${esc(state.seed)} · rng ${state.rngState>>>0}</small><button data-act="debug-add">全属性+5 / 资源</button><button data-act="debug-year">跳至仙门阶段</button><button data-act="debug-chapter">境界前进一章</button><button data-act="debug-root">指定下一种灵根</button><button data-act="debug-sect">指定下一门派</button><select id="debug-event-select">${[...D.MORTAL_CHAINS,...D.CULTIVATION_CHAINS].map(c=>`<option value="${esc(c.eventId)}">${esc(c.title)}</option>`).join('')}</select><button data-act="debug-event">触发所选事件</button><select id="debug-npc-select">${D.NPCS.map(n=>`<option value="${esc(n.id)}">${esc(n.name)}</option>`).join('')}</select><button data-act="debug-npc-up">所选NPC好感+25</button><button data-act="debug-npc-down">所选NPC好感-25</button><button data-act="debug-eliminate">触发门派淘汰</button><button data-act="debug-rescue">触发隐藏翻盘</button><button data-act="debug-death">触发死亡</button><button data-act="debug-ascend">触发飞升</button><button data-act="debug-assets">检查资源路径</button><pre>${esc(JSON.stringify(state,null,2))}</pre>`:''}</aside>`}

  function render(){
    let main='';if(ui.screen==='home'||ui.screen==='seed')main=homeScreen();else if(ui.screen==='setup')main=setupScreen();else if(ui.screen==='event')main=eventScreen();else if(ui.screen==='assembly-transition')main=assemblyTransition();else if(ui.screen==='sect-choice')main=sectChoice();else if(ui.screen==='path-choice')main=pathChoice();else if(ui.screen==='decade')main=decadeScreen();else if(ui.screen==='summary')main=summaryScreen();else if(ui.screen==='ending')main=endingScreen();else main=homeScreen();
    app.innerHTML=`${state&&ui.screen!=='home'?topBar():''}<main class="page">${main}</main>${bottomNav()}${debugPanel()}`;
    modalRoot.innerHTML=ui.showChronicle?chronicleModal():ui.showHeaven?heavenModal():ui.showBag?bagModal():'';
  }
  function randomName(){const m=['顾长歌','沈砚','陆玄','萧景行','楚云生','谢无咎','裴照夜','周既白'],f=['沈清霜','苏晚月','宁知微','叶青璃','顾云舒','谢明珠','裴映雪','周含章'];state.name=rng.pick(state.gender==='女'?f:m);syncRng();render()}
  function validateName(){const el=document.getElementById('name-input');const name=(el?.value||'').trim().replace(/[<>]/g,'').slice(0,16);if(!name){toast('命书不可无名','bad');return}state.name=name;ui.setupStep='attrs';render()}
  function changeAttr(key,delta){const used=Object.values(state.attributes).reduce((a,b)=>a+b,0);if(delta>0&&used>=20)return;if(delta<0&&state.attributes[key]<=0)return;state.attributes[key]+=delta;render()}
  function generateShareCard(){
    const canvas=document.getElementById('share-canvas');if(!canvas)return;const ctx=canvas.getContext('2d');const grad=ctx.createLinearGradient(0,0,0,1440);grad.addColorStop(0,'#10211c');grad.addColorStop(1,'#e8ddc5');ctx.fillStyle=grad;ctx.fillRect(0,0,1080,1440);ctx.strokeStyle='#c8a85e';ctx.lineWidth=4;ctx.strokeRect(46,46,988,1348);ctx.fillStyle='#eadfbd';ctx.font='58px serif';ctx.fillText('修 仙 之 路',88,142);ctx.font='96px serif';ctx.fillText(state.name,88,285);ctx.font='42px serif';ctx.fillStyle='#d5c490';ctx.fillText(`${state.gender} · 享年 ${state.age} 岁 · ${D.REALMS[state.realm]?.name}`,88,360);ctx.font='50px serif';ctx.fillStyle='#24251f';ctx.fillText(state.ending.title,88,760);ctx.font='35px serif';ctx.fillText(`宗门：${byId(D.SECTS,state.sect)?.name||'无门'}`,88,850);ctx.fillText(`道途：${byId(D.PATHS,state.path)?.name||'凡人'}`,88,910);ctx.fillText(`称号：${state.titles.at(-1)||'无名'}`,88,970);ctx.fillText(`道侣：${state.flags.partnerShen?'沈清霜':'无'}`,88,1030);ctx.fillText(`功法：${state.skills.slice(0,3).join('、')||'无'}`,88,1090);ctx.fillStyle='#8c2d28';ctx.font='42px monospace';ctx.fillText(`命数 ${state.seed}`,88,1305);canvas.toBlob(async blob=>{const file=new File([blob],`修仙之路-${state.name}.png`,{type:'image/png'});try{if(navigator.canShare?.({files:[file]}))await navigator.share({files:[file],title:'我的修仙之路',text:`命数 ${state.seed}`});else{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=file.name;a.click();toast('道途卡已生成，可保存分享','good')}}catch{toast('已取消分享')}})
  }
  async function copySeed(link=false){const text=link?`${location.origin}${location.pathname}?seed=${state.seed}`:state.seed;try{await navigator.clipboard.writeText(text);toast(link?'同命挑战链接已复制':'命数已复制','good')}catch{toast(`请复制：${text}`)}}
  async function assetCheck(){const paths=[...new Set([...document.querySelectorAll('img')].map(x=>x.getAttribute('src')).filter(Boolean))];const results=await Promise.all(paths.map(async p=>{try{return {p,ok:(await fetch(p,{method:'HEAD'})).ok}}catch{return {p,ok:false}}}));const bad=results.filter(x=>!x.ok);toast(bad.length?`${bad.length} 个当前页面资源异常`:`当前页面 ${paths.length} 个资源均可访问`,bad.length?'bad':'good');console.table(results)}

  function act(name,el){
    if(name!=='music'&&name!=='home')audio.unlock();
    if(!['music','sfx','volume-down','volume-up'].includes(name))audio.cue('click');
    if(name==='start')startGame(SEEDED||randomSeed());
    else if(name==='seed-open'){ui.screen='seed';ui.seedInput=SEEDED||'';render()}
    else if(name==='seed-close'){ui.screen='home';ui.seedInput='';render()}
    else if(name==='seed-start'){const v=document.getElementById('seed-input')?.value;if(!cleanSeed(v)){toast('请输入有效命数','bad');return}startGame(v)}
    else if(name==='gender'){state.gender=el.dataset.value;ui.setupStep='name';render()}
    else if(name==='random-name')randomName();
    else if(name==='name-next')validateName();
    else if(name==='setup-back'){ui.setupStep=ui.setupStep==='name'?'gender':'name';render()}
    else if(name==='attr-plus')changeAttr(el.dataset.key,1);
    else if(name==='attr-minus')changeAttr(el.dataset.key,-1);
    else if(name==='attr-all'){const left=20-Object.values(state.attributes).reduce((a,b)=>a+b,0);state.attributes[el.dataset.key]+=left;render()}
    else if(name==='attr-reset'){state.attributes=emptyAttrs();render()}
    else if(name==='attrs-confirm'){if(Object.values(state.attributes).reduce((a,b)=>a+b,0)!==20)return;decideInnate();state.maxHealth=70+state.attributes.tipo*5+state.attributes.gengu*2;state.health=state.maxHealth;state.lifespan=72+state.attributes.gengu*2+state.attributes.tipo;ui.setupStep='tags';render()}
    else if(name==='enter-mortal')enterMortal();
    else if(name==='choice')resolveChoice(Number(el.dataset.index));
    else if(name==='continue-result')continueResult();
    else if(name==='summary-next')continueAfterSummary();
    else if(name==='assembly-enter'){state.phase='assembly';state.year=10;state.age=20;openChain('mortal_assembly')}
    else if(name==='sect')chooseSect(el.dataset.value);
    else if(name==='hidden-rescue')acceptHiddenRescue();
    else if(name==='mortal-ending')rejectToEnding();
    else if(name==='path')choosePath(el.dataset.value);
    else if(name==='open-turn-event')openChain(el.dataset.value);
    else if(name==='end-decade')endDecade();
    else if(name==='breakthrough')breakthrough();
    else if(name==='claim-demon')showEnding('魔道至尊','你没有踏入天门，而是让万魔俯首。此界从此以你的意志划分昼夜，这是胜利，也是无尽业火的开始。','secondary');
    else if(name==='claim-ancestor')showEnding('一方老祖','你止步天门之前，开宗立派，将一生所得传给后来者。千年后，世人仍在祖师殿里念你的名。','secondary');
    else if(name==='claim-guardian')showEnding('人间守望','你放下飞升执念，把余生留给山河凡俗。此生未成仙，却让许多人得以活完一生。','secondary');
    else if(name==='claim-jade')showEnding('上古道祖','两块残玉开启失落洞天。你继承的不是一件仙器，而是一条早已断绝的大道。','secondary');
    else if(name==='chronicle'){ui.showChronicle=true;ui.showHeaven=ui.showBag=false;render()}
    else if(name==='heaven'){ui.showHeaven=true;ui.showChronicle=ui.showBag=false;render()}
    else if(name==='bag'){ui.showBag=true;ui.showChronicle=ui.showHeaven=false;render()}
    else if(name==='modal-close'){ui.showBag=ui.showChronicle=ui.showHeaven=false;render()}
    else if(name==='music'){settings.music=!settings.music;saveSettings();if(settings.music){audio.unlock();audio.play(phaseMusic())}else audio.stop();render()}
    else if(name==='sfx'){settings.sfx=!settings.sfx;saveSettings();if(settings.sfx)audio.cue('success');render()}
    else if(name==='motion'){settings.motion=!settings.motion;saveSettings();render()}
    else if(name==='volume-down'){settings.volume=clamp(settings.volume-.08,.08,.72);if(audio.current)audio.current.volume=settings.volume;saveSettings();render()}
    else if(name==='volume-up'){settings.volume=clamp(settings.volume+.08,.08,.72);if(audio.current)audio.current.volume=settings.volume;saveSettings();audio.cue('success');render()}
    else if(name==='home'){if(confirm('本局没有保存。确定返回首页，结束此生吗？')){state=null;ui.screen='home';audio.play('home');render()}}
    else if(name==='restart'){state=null;ui.screen='home';ui.seedInput='';render()}
    else if(name==='share')generateShareCard();
    else if(name==='copy-seed')copySeed(false);
    else if(name==='safe-return'){ui.screen=state.phase==='cultivation'?'decade':'home';render()}
    else if(name==='debug-toggle'){ui.debugOpen=!ui.debugOpen;render()}
    else if(name==='debug-add'){Object.keys(state.attributes).forEach(k=>state.attributes[k]+=5);state.spiritStones+=500;state.silver+=100;state.cultivation+=1000;state.lifespan+=500;render()}
    else if(name==='debug-year'){state.phase='cultivation';state.year=20;state.age=30;state.realm=Math.max(1,state.realm);state.sect=state.sect||'qingxuan';state.path=state.path||'sword';prepareDecade()}
    else if(name==='debug-chapter'){state.phase='cultivation';state.sect=state.sect||'qingxuan';state.path=state.path||'sword';state.realm=Math.min(8,state.realm+2);state.cultivation=Math.max(state.cultivation,D.REALMS[state.realm]?.need||0);state.lifespan=Math.max(state.lifespan,state.age+300);prepareDecade()}
    else if(name==='debug-root'){const i=Math.max(-1,D.ROOTS.findIndex(r=>r.id===state.spiritualRoot));state.spiritualRoot=D.ROOTS[(i+1)%D.ROOTS.length].id;toast(`灵根：${byId(D.ROOTS,state.spiritualRoot).name}`,'good');render()}
    else if(name==='debug-sect'){const i=Math.max(-1,D.SECTS.findIndex(s=>s.id===state.sect));state.sect=D.SECTS[(i+1)%D.SECTS.length].id;toast(`门派：${byId(D.SECTS,state.sect).name}`,'good');render()}
    else if(name==='debug-event'){const id=document.getElementById('debug-event-select')?.value;if(id){state.phase=getChain(id)?.phase==='mortal'?'mortal':'cultivation';openChain(id)}}
    else if(name==='debug-npc-up'||name==='debug-npc-down'){const id=document.getElementById('debug-npc-select')?.value,n=state.npcs[id];if(n){n.relation=clamp(n.relation+(name.endsWith('up')?25:-25),-100,100);n.memories.push({year:state.year,event:'调试关系',relation:name.endsWith('up')?25:-25});render()}}
    else if(name==='debug-eliminate'){state.phase='assembly';state.flags.invites=[];state.flags.assemblyReasons=['调试：强制淘汰'];ui.screen='sect-choice';render()}
    else if(name==='debug-rescue'){state.flags.helpedTaoist=true;state.npcs.mowenchen.relation=30;acceptHiddenRescue()}
    else if(name==='debug-death')showEnding('调试 · 身陨','这是由调试面板触发的死亡验收。','death');
    else if(name==='debug-ascend')showEnding('白日飞升','这是由调试面板触发的飞升验收。','ascension');
    else if(name==='debug-assets')assetCheck();
  }
  app.addEventListener('click',(e)=>{const el=e.target.closest('[data-act]');if(el)act(el.dataset.act,el)});
  modalRoot.addEventListener('click',(e)=>{if(e.target.closest('[data-stop]')&&!e.target.closest('[data-act]'))return;const el=e.target.closest('[data-act]');if(el)act(el.dataset.act,el)});
  document.addEventListener('keydown',(e)=>{if(e.key==='Enter'&&ui.screen==='setup'&&ui.setupStep==='name')validateName()});
  render();
})();
