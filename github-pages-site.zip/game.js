(function () {
  'use strict';
  const D = window.GAME_DATA;
  const app = document.getElementById('app');
  const modalRoot = document.getElementById('modal-root');
  const fxRoot = document.getElementById('fx-root');
  const toastRoot = document.getElementById('toast-root');
  let view = 'title';
  let soundOn = true;
  let audio = {ctx:null,master:null,music:null,sfx:null,delay:null,loop:null,bar:0,wind:null};
  let draft = { sect:0, root:0, path:0, points:24, attrs:Object.fromEntries(D.ATTRS.map(a => [a.key,2])) };
  let state = null;

  const clamp = (n,min,max) => Math.max(min,Math.min(max,n));
  const rand = (arr) => arr[Math.floor(Math.random()*arr.length)];
  const esc = (s) => String(s ?? '').replace(/[&<>'"]/g,c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const attrMeta = key => D.ATTRS.find(a => a.key === key);
  const skillMeta = name => D.SKILLS.find(x => x.name === name);
  const artifactMeta = name => D.ARTIFACTS.find(x => x.name === name);
  const pillMeta = name => D.PILLS.find(x => x.name === name);
  const pathMeta = () => D.PATHS.find(x => x.id === state.path);
  const sectMeta = () => D.SECTS.find(x => x.id === state.sect);
  const rootMeta = () => D.ROOTS.find(x => x.id === state.root);
  const realm = () => D.REALMS[state.realm];

  function initAudio() {
    if (audio.ctx) return audio.ctx;
    try {
      const Ctx=window.AudioContext||window.webkitAudioContext,ctx=new Ctx();
      const master=ctx.createGain(),music=ctx.createGain(),sfx=ctx.createGain(),comp=ctx.createDynamicsCompressor();
      master.gain.value=.78;music.gain.value=0;sfx.gain.value=.56;
      music.connect(master);sfx.connect(master);master.connect(comp);comp.connect(ctx.destination);
      const delay=ctx.createDelay(.8),feedback=ctx.createGain();delay.delayTime.value=.31;feedback.gain.value=.2;delay.connect(feedback);feedback.connect(delay);delay.connect(music);
      const buffer=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate),data=buffer.getChannelData(0);
      for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*(1-i/data.length*.15);
      const wind=ctx.createBufferSource(),filter=ctx.createBiquadFilter(),windGain=ctx.createGain();wind.buffer=buffer;wind.loop=true;filter.type='lowpass';filter.frequency.value=420;windGain.gain.value=.012;wind.connect(filter).connect(windGain).connect(music);wind.start();
      audio={...audio,ctx,master,music,sfx,delay,wind};return ctx;
    } catch (_) { return null; }
  }

  function instrument(freq,time,duration=.8,voice='qin',volume=.055,target='music') {
    const ctx=audio.ctx;if(!ctx)return;const out=target==='sfx'?audio.sfx:audio.music;
    const gain=ctx.createGain(),filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=voice==='flute'?2600:1800;
    gain.gain.setValueAtTime(.0001,time);gain.gain.exponentialRampToValueAtTime(volume,time+.025);gain.gain.exponentialRampToValueAtTime(.0001,time+duration);
    const osc=ctx.createOscillator();osc.type=voice==='flute'?'sine':voice==='bell'?'sine':'triangle';osc.frequency.setValueAtTime(freq,time);
    if(voice==='qin')osc.frequency.exponentialRampToValueAtTime(freq*.992,time+duration);
    if(voice==='flute'){const lfo=ctx.createOscillator(),depth=ctx.createGain();lfo.frequency.value=5.1;depth.gain.value=freq*.006;lfo.connect(depth).connect(osc.frequency);lfo.start(time);lfo.stop(time+duration);}
    osc.connect(filter).connect(gain).connect(out);if(target==='music'&&audio.delay)gain.connect(audio.delay);
    osc.start(time);osc.stop(time+duration+.04);
    if(voice==='qin'){const overtone=ctx.createOscillator(),og=ctx.createGain();overtone.type='sine';overtone.frequency.value=freq*2;og.gain.setValueAtTime(volume*.25,time);og.gain.exponentialRampToValueAtTime(.0001,time+duration*.42);overtone.connect(og).connect(out);overtone.start(time);overtone.stop(time+duration*.5);}
  }

  function scheduleBar() {
    if(!soundOn||!audio.ctx)return;const ctx=audio.ctx,now=ctx.currentTime+.06;
    const base=state&&state.demon>65?130.81:state&&state.realm>=5?174.61:146.83;
    const scale=[0,2,5,7,9,12].map(n=>base*Math.pow(2,n/12));
    const phrases=[[0,2,3,2,4,3,2,1],[0,1,2,4,3,2,1,0],[2,3,5,4,3,1,2,0],[0,2,1,3,2,4,3,2]];
    const phrase=phrases[audio.bar%phrases.length];
    instrument(base/2,now,3.2,'qin',.026);
    phrase.forEach((n,i)=>instrument(scale[n],now+i*.41,.58,'qin',i%4===0?.06:.042));
    instrument(scale[(audio.bar+3)%5],now+.22,2.5,'flute',.024);
    if(audio.bar%4===0)instrument(base*4,now+.04,2.1,'bell',.018);
    audio.bar++;
  }

  function startMusic() {
    if(!soundOn)return;const ctx=initAudio();if(!ctx)return;ctx.resume?.();
    audio.music.gain.cancelScheduledValues(ctx.currentTime);audio.music.gain.setValueAtTime(audio.music.gain.value,ctx.currentTime);audio.music.gain.linearRampToValueAtTime(.34,ctx.currentTime+1.2);
    if(!audio.loop){scheduleBar();audio.loop=setInterval(scheduleBar,3300);}
  }
  function stopMusic() {
    if(audio.loop){clearInterval(audio.loop);audio.loop=null;}if(audio.ctx&&audio.music){const t=audio.ctx.currentTime;audio.music.gain.cancelScheduledValues(t);audio.music.gain.setValueAtTime(audio.music.gain.value,t);audio.music.gain.linearRampToValueAtTime(0,t+.45);}
  }
  function toggleSound(){soundOn=!soundOn;if(soundOn)startMusic();else stopMusic();render();toast(soundOn?'古琴与洞箫已启':'山音已静');}

  function ping(kind='soft') {
    if (navigator.vibrate) navigator.vibrate(kind === 'danger' ? [22,30,38] : 18);
    if(!soundOn)return;const ctx=initAudio();if(!ctx)return;ctx.resume?.();const t=ctx.currentTime;
    if(kind==='success'){instrument(523.25,t,.42,'bell',.08,'sfx');instrument(783.99,t+.09,.62,'bell',.055,'sfx');}
    else if(kind==='danger'){instrument(123.47,t,.38,'qin',.09,'sfx');instrument(92.5,t+.07,.55,'qin',.07,'sfx');}
    else instrument(329.63,t,.22,'qin',.05,'sfx');
  }

  function rewardSound(type){if(!soundOn)return;const ctx=initAudio();if(!ctx)return;const t=ctx.currentTime+.02;
    const notes=type==='artifact'?[293.66,440,587.33]:type==='skill'?[261.63,392,523.25]:type==='fortune'?[392,523.25,659.25,783.99]:type==='breakthrough'?[196,293.66,392,587.33]:type==='injury'?[146.83,110]:[329.63,493.88];
    notes.forEach((n,i)=>instrument(n,t+i*.1,type==='injury'?.32:.7,type==='injury'?'qin':'bell',type==='injury'?.075:.055,'sfx'));
  }

  function showRewardFx(cue) {
    if(!cue||!fxRoot)return;const bits=Array.from({length:18},(_,i)=>`<i style="--i:${i};--r:${52+Math.random()*85}px"></i>`).join('');
    fxRoot.innerHTML=`<div class="reward-fx fx-${cue.type}"><div class="fx-vignette"></div><div class="fx-rays"></div><div class="fx-particles">${bits}</div><div class="fx-token"><span>${cue.glyph}</span></div><div class="fx-copy"><small>${esc(cue.kicker)}</small><b>${esc(cue.label)}</b></div></div>`;
    rewardSound(cue.type);setTimeout(()=>{if(fxRoot)fxRoot.innerHTML='';},2300);
  }

  function toast(text,type='') {
    toastRoot.innerHTML = `<div class="toast ${type}">${esc(text)}</div>`;
    setTimeout(() => { if (toastRoot) toastRoot.innerHTML=''; },2200);
  }

  function renderTitle() {
    app.innerHTML = `<section class="screen hero-screen">
      <div class="hero-wash"></div>
      <button class="corner-btn sound-btn ${soundOn?'music-live':''}" data-act="sound" aria-label="切换古风音乐">${soundOn?'♫':'静'}</button>
      <button class="corner-btn help-btn" data-act="help" aria-label="查看玩法">?</button>
      <div class="hero-content">
        <p class="eyebrow">高难度 · 单局轮回 · 无存档</p>
        <h1>修仙之路</h1>
        <p class="seal-line"><span></span>十年一梦，万劫问道<span></span></p>
        <p class="hero-copy">择一宗，修一途。你只有此生，能否走到云海尽头？</p>
        <button class="primary-btn" data-act="begin" type="button">踏入仙途 <b>→</b></button>
        <p class="quiet">${D.SECTS.length} 门派 · ${D.PATHS.length} 流派 · ${D.EVENTS.length} 则命运事件</p>
      </div><div class="scroll-cue">刷新即重开 · 不会保存任何进度</div>
    </section>`;
  }

  const cardGrid = (items,type,selected) => `<div class="choice-grid ${type}-grid">${items.map((x,i) => `<button class="choice-card ${selected===i?'selected':''}" data-act="select-${type}" data-index="${i}">
    <span class="choice-icon">${esc(x.sigil||x.icon)}</span><span class="choice-main"><b>${esc(x.name)}</b><small>${esc(x.tag||x.desc)}</small></span>
    ${x.tag?`<em>${esc(x.desc)}</em>`:''}<i>✓</i></button>`).join('')}</div>`;

  function renderCreation() {
    const s=D.SECTS[draft.sect], r=D.ROOTS[draft.root], p=D.PATHS[draft.path];
    app.innerHTML = `<section class="creation-screen paper-screen">
      <header class="topbar"><button class="text-btn" data-act="home">‹ 返回</button><div><span>命格初定</span><b>开局构筑</b></div><button class="round-btn" data-act="help">?</button></header>
      <div class="creation-hero"><div><p>甲辰年 · 山门初开</p><h2>此身从何处问道？</h2></div><span class="big-seal">命</span></div>
      <div class="creation-body">
        <section class="creation-step"><div class="step-head"><span>壹</span><div><h3>选择门派</h3><p>门派决定先天禀赋与一项贯穿全局的被动。</p></div></div>${cardGrid(D.SECTS,'sect',draft.sect)}</section>
        <section class="creation-step"><div class="step-head"><span>贰</span><div><h3>选择灵根 / 体质</h3><p>没有最强灵根，只有与你道途相合的命数。</p></div></div>${cardGrid(D.ROOTS,'root',draft.root)}</section>
        <section class="creation-step"><div class="step-head"><span>叁</span><div><h3>选择主修流派</h3><p>主修双属性会共同参与战斗与宗门大比。</p></div></div>${cardGrid(D.PATHS,'path',draft.path)}</section>
        <section class="creation-step stat-step"><div class="step-head"><span>肆</span><div><h3>分配十维命数</h3><p>单项最高 8。失败往往源于短板，而非单纯运气。</p></div><strong>余 ${draft.points} 点</strong></div>
          <div class="attr-grid">${D.ATTRS.map(a => `<div class="attr-row"><span class="attr-glyph">${a.icon}</span><div><b>${a.name}</b><small>${a.desc}</small></div><div class="stepper"><button data-act="stat-minus" data-key="${a.key}" ${draft.attrs[a.key]<=1?'disabled':''}>−</button><strong>${draft.attrs[a.key]}</strong><button data-act="stat-plus" data-key="${a.key}" ${draft.points<=0||draft.attrs[a.key]>=8?'disabled':''}>＋</button></div></div>`).join('')}</div>
        </section>
        <section class="fate-preview"><span class="preview-seal">鉴</span><div><p>你的命格</p><h3>${s.name} · ${r.name} · ${p.name}</h3><small>${s.passive}</small></div></section>
        <button class="primary-btn wide" data-act="start" ${draft.points!==0?'disabled':''}>${draft.points===0?'立誓入道':'尚有命数未分配'} <b>→</b></button>
        <p class="creation-note">一旦立誓，本局不可更改。你的选择不会被保存。</p>
      </div>
    </section>`;
  }

  function startGame() {
    const s=D.SECTS[draft.sect], r=D.ROOTS[draft.root], p=D.PATHS[draft.path];
    const attrs={...draft.attrs};
    [s.mods,r.mods].forEach(mods => Object.entries(mods||{}).forEach(([k,v]) => attrs[k]=(attrs[k]||0)+v));
    const maxHp = 70 + attrs.tipo*5 + (r.hp||0) + (s.id==='tiegum'?20:0) + (p.id==='body'?12:0);
    const lifeSpan = 112 + attrs.gengu*2 + (r.life||0) + (s.id==='baicao'?15:0);
    state = {
      sect:s.id,root:r.id,path:p.id,attrs,age:16,lifeSpan,maxHp,hp:maxHp,xp:0,realm:0,demon:s.id==='wuxiang'?10:0,
      karma:s.id==='wuxiang'?8:0,allies:0,enemies:0,skills:[p.skill],artifacts:[],pills:[],skillPoints:0,buffs:[],
      turn:0,eventIndex:0,eventQueue:[],seen:[],history:[],turnLogs:[],phase:'event',scry:2,deathWard:s.id==='lingtai'?1:0,
      stats:{events:0,success:0,fail:0,battles:0,breaks:0},before:null,result:null
    };
    if (s.id==='baicao') state.pills.push('回春丹','清心丹');
    if (s.id==='wuxiang') state.skills.push('燃血秘术');
    if (r.id==='lei') state.artifacts.push('避雷珠');
    view='game'; beginTurn(); startMusic();ping('success');
  }

  function snapshot() { return {age:state.age,hp:state.hp,xp:state.xp,demon:state.demon,karma:state.karma,lifeSpan:state.lifeSpan,realm:state.realm}; }
  function tierForRealm() { return state.realm<=2?0:state.realm<=5?1:2; }
  function drawEvents(count) {
    const tier=tierForRealm();
    let pool=D.EVENTS.filter(e => Math.abs(e.tier-tier)<= (state.sect==='sanxiu'?1:0) && !state.seen.slice(-14).includes(e.id));
    if (pool.length<count) pool=D.EVENTS.filter(e=>e.tier===tier);
    const picked=[];
    while(picked.length<count && pool.length){const i=Math.floor(Math.random()*pool.length);picked.push(pool.splice(i,1)[0]);}
    state.seen.push(...picked.map(e=>e.id)); return picked;
  }
  function beginTurn() {
    state.turn++; state.eventIndex=0; state.turnLogs=[]; state.before=snapshot(); state.result=null; state.phase='event';
    const count=2+(Math.random()<.58?1:0); state.eventQueue=drawEvents(count); render();
  }

  function attrValue(code) {
    const vals=Object.values(state.attrs);
    if (code==='best') return Math.max(...vals);
    if (code==='worst') return Math.min(...vals);
    if (code==='path') { const [a,b]=pathMeta().attrs; return (state.attrs[a]+state.attrs[b])/2; }
    return state.attrs[code]||0;
  }
  function globalBonus(event,opt) {
    let b=0; const s=sectMeta();
    if (s.id==='qingxuan' && (event.art==='sword'||state.path==='sword')) b+=8;
    if (s.id==='wanfa' && ['shenshi','lingli'].includes(opt.attr)) b+=5;
    if (state.skills.includes('破妄瞳') && ['demon','ghost'].includes(event.art)) b+=12;
    if (state.skills.includes('御剑术') && event.art==='sword') b+=7;
    if (state.artifacts.includes('照妖镜') && ['demon','ghost'].includes(event.art)) b+=8;
    if (state.artifacts.includes('八卦云盘') && opt.attr==='shenshi') b+=5;
    if (state.skills.includes('万象杂篇') && opt.attr==='worst') b+=6;
    b += Math.min(8,state.attrs.qiyun*.55) + Math.min(5,state.allies*.4) - Math.min(10,state.enemies*.7);
    return b;
  }
  function chanceFor(event,opt) {
    if (opt.safe) return 100;
    const raw=43+attrValue(opt.attr)*6+globalBonus(event,opt)-opt.diff*5;
    return Math.round(clamp(raw,7,93));
  }
  function riskLabel(n) { return n>=78?'胜券较稳':n>=58?'尚可一试':n>=38?'颇为凶险':'九死一生'; }
  function currentEvent() { return state.eventQueue[state.eventIndex]; }

  function randomSkill(rare=false) {
    const pool=D.SKILLS.filter(x=>!state.skills.includes(x.name) && (!rare || ['仙法','道法','瞳术'].includes(x.type)));
    return (rand(pool.length?pool:D.SKILLS)).name;
  }
  function randomArtifact() { return rand(D.ARTIFACTS.filter(x=>!state.artifacts.includes(x.name)).length?D.ARTIFACTS.filter(x=>!state.artifacts.includes(x.name)):D.ARTIFACTS).name; }
  function randomPill(rare=false) { const pool=rare?D.PILLS.slice(6):D.PILLS; return rand(pool).name; }
  function addUnique(arr,item,max=99) { if (!arr.includes(item) && arr.length<max) { arr.push(item); return true; } return false; }
  function effectNotes(effect,success) {
    const notes=[]; const e={...effect};
    if (e.xp) {state.xp=Math.max(0,state.xp+e.xp);notes.push(`修为 ${e.xp>0?'+':''}${e.xp}`);}
    if (e.hp) {let dmg=e.hp; if(dmg<0){ if(state.skills.includes('金钟护体')) dmg+=4;if(sectMeta().id==='tiegum') dmg=Math.round(dmg*.82);if(state.skills.includes('伏魔棍典')) dmg=Math.round(dmg*.85);} state.hp=clamp(state.hp+dmg,0,state.maxHp);notes.push(`气血 ${dmg>0?'+':''}${dmg}`);}
    if (e.life) {state.lifeSpan=Math.max(state.age+1,state.lifeSpan+e.life);notes.push(`寿元 ${e.life>0?'+':''}${e.life}`);}
    if (e.demon) {let d=e.demon; if(d>0&&state.skills.includes('抱元守一')) d=Math.round(d*.8);if(d>0&&sectMeta().id==='wuxiang')d=Math.round(d*1.2);state.demon=clamp(state.demon+d,0,120);notes.push(`心魔 ${d>0?'+':''}${d}`);}
    if (e.karma) {state.karma=clamp(state.karma+e.karma,-40,120);notes.push(`业障 ${e.karma>0?'+':''}${e.karma}`);}
    if (e.ally) {state.allies=Math.max(0,state.allies+e.ally);notes.push(`人脉 ${e.ally>0?'+':''}${e.ally}`);}
    if (e.enemy) {state.enemies=Math.max(0,state.enemies+e.enemy);notes.push(`仇敌 ${e.enemy>0?'+':''}${e.enemy}`);}
    if (e.skillPoint) {state.skillPoints+=e.skillPoint;notes.push(`悟道点 +${e.skillPoint}`);}
    if (e.attr) {
      if (e.attr==='weakest') {const min=Math.min(...Object.values(state.attrs));const key=Object.keys(state.attrs).find(k=>state.attrs[k]===min);state.attrs[key]++;notes.push(`${attrMeta(key).name} +1`);}
      else Object.entries(e.attr).forEach(([k,v])=>{state.attrs[k]+=v;notes.push(`${attrMeta(k).name} ${v>0?'+':''}${v}`);});
    }
    if (e.skill) {const name=e.skill==='random'?randomSkill():e.skill==='rare'?randomSkill(true):e.skill;if(addUnique(state.skills,name,12))notes.push(`领悟《${name}》`);else {state.xp+=18;notes.push('旧法新悟：修为 +18');}}
    if (e.artifact) {const name=e.artifact==='random'?randomArtifact():e.artifact==='天外陨铁'?randomArtifact():e.artifact;if(addUnique(state.artifacts,name,8))notes.push(`获得法宝「${name}」`);else {state.xp+=16;notes.push('法宝化灵：修为 +16');}}
    if (e.pill) {const name=e.pill==='random'?randomPill():e.pill==='rare'?randomPill(true):e.pill;state.pills.push(name);notes.push(`获得丹药「${name}」`);}
    if (e.artifactLose&&state.artifacts.length){const lost=state.artifacts.splice(Math.floor(Math.random()*state.artifacts.length),1)[0];notes.push(`失去「${lost}」`);}
    if (e.pillLose&&state.pills.length){const lost=state.pills.shift();notes.push(`失去「${lost}」`);}
    if (!notes.length) notes.push(success?'平安无事':'未伤根本');
    return notes;
  }

  function cueFromEffect(effect,notes,success) {
    const e=effect||{},find=(prefix)=>notes.find(n=>n.startsWith(prefix));
    if(!success){
      if((e.hp||0)<0)return {type:'injury',glyph:'伤',kicker:'经脉受创',label:'一步踏错'};
      if((e.demon||0)>0)return {type:'demon',glyph:'魔',kicker:'心关失守',label:'心魔滋长'};
      return {type:'omen',glyph:'凶',kicker:'天机反噬',label:'因缘未成'};
    }
    const artifact=find('获得法宝');if(artifact)return {type:'artifact',glyph:'宝',kicker:'神兵认主',label:artifact.match(/「(.+?)」/)?.[1]||'无名法宝'};
    const skill=find('领悟《');if(skill)return {type:'skill',glyph:'法',kicker:'道韵自生',label:skill.match(/《(.+?)》/)?.[1]||'上古功法'};
    const pill=find('获得丹药');if(pill)return {type:'pill',glyph:'丹',kicker:'丹香盈袖',label:pill.match(/「(.+?)」/)?.[1]||'灵丹'};
    if((e.life||0)>0||(e.ally||0)>1||e.pill)return {type:'fortune',glyph:'福',kicker:'金运照命',label:'福缘临门'};
    if(e.attr||e.skillPoint)return {type:'insight',glyph:'悟',kicker:'灵台清明',label:find('悟道点')||find('旧法新悟')||'命数精进'};
    if((e.xp||0)>=45)return {type:'cultivation',glyph:'修',kicker:'灵潮入体',label:`修为精进 ${e.xp}`};
    return {type:'plain',glyph:'吉',kicker:'因缘有成',label:notes[0]||'平安无事'};
  }

  function optionOmen(option) {
    const e=option.success||{};
    if(e.artifact)return {type:'artifact',glyph:'宝'};
    if(e.skill)return {type:'skill',glyph:'法'};
    if(e.pill)return {type:'pill',glyph:'丹'};
    if((e.life||0)>0||(e.ally||0)>1)return {type:'fortune',glyph:'缘'};
    if((e.xp||0)>=45)return {type:'cultivation',glyph:'悟'};
    if((option.fail?.hp||0)<=-20||(option.fail?.demon||0)>=12)return {type:'danger',glyph:'险'};
    return {type:'plain',glyph:'·'};
  }

  function resolveOption(index) {
    if (state.phase!=='event'||state.result) return;
    const event=currentEvent(),opt=event.options[index],chance=chanceFor(event,opt);
    const success=opt.safe||Math.random()*100<chance;
    const effect=success?opt.success:opt.fail;
    const notes=effectNotes(effect,success);
    const narrative=opt.result?.[success?'success':'fail'] || (success?'你顺利了结了这桩因缘。':'这次选择没有得到预想的结果。');
    state.stats.events++; state.stats[success?'success':'fail']++;
    if (['sword','beast','storm'].includes(event.art)) state.stats.battles++;
    const line=`${event.title}：${narrative}（${notes.join('，')}）`;
    state.turnLogs.push(line); state.history.unshift({age:state.age,title:event.title,choice:opt.label,success,notes,narrative});
    const cue=cueFromEffect(effect,notes,success);
    state.result={success,choice:opt.label,chance,notes,cue,narrative};
    ping(success?'success':'danger');
    if(checkImmediateEnd()) return; render();setTimeout(()=>showRewardFx(cue),30);
  }

  function checkImmediateEnd() {
    if (state.hp<=0) {
      if (state.buffs.includes('还魂')) {state.buffs.splice(state.buffs.indexOf('还魂'),1);state.hp=Math.max(25,Math.round(state.maxHp*.3));toast('九转还魂丹护住了最后一口气','good');return false;}
      if (state.deathWard>0) {state.deathWard--;state.hp=1;toast('金身护体：你从死境中撑了回来','good');return false;}
      showEnding('战死道消','你的气血在此战中彻底断绝。仙途从不因豪情而手下留情。','death');return true;
    }
    if (state.demon>=100) {showEnding('走火入魔','心魔吞没最后一丝清明。世人后来只记得一尊无名邪祟。','death');return true;}
    return false;
  }

  function continueEvent() { fxRoot.innerHTML='';state.result=null; state.eventIndex++; if(state.eventIndex>=state.eventQueue.length)state.phase='turnEnd'; render(); }
  function scry() {
    if(state.scry<=0||state.result)return;
    const cost=sectMeta().id==='sanxiu'?3:6;
    state.lifeSpan-=cost; state.scry--; const old=currentEvent();
    let pool=D.EVENTS.filter(e=>e.tier===tierForRealm()&&e.id!==old.id&&!state.eventQueue.some(x=>x.id===e.id));
    state.eventQueue[state.eventIndex]=rand(pool); state.turnLogs.push(`推演天机：避开「${old.title}」，折寿 ${cost} 年。`); ping('soft'); render();
  }

  function decadePractice() {
    let gain=Math.round((state.attrs.gengu+state.attrs.lingli+state.attrs.wuxing)*1.25)+4;
    if(sectMeta().id==='taixu')gain+=10;if(state.skills.includes('太虚吐纳法'))gain+=8;if(state.skills.includes('小周天诀'))gain+=10;
    if(sectMeta().id==='wanfa')gain+=Math.min(12,state.skills.length*2);
    state.xp+=gain;
    let heal=5+Math.floor(state.attrs.gengu/2); if(state.skills.includes('枯木逢春'))heal+=8;
    state.hp=clamp(state.hp+heal,0,state.maxHp);
    let calm=2+Math.floor(state.attrs.daoxin/3);if(state.artifacts.includes('养魂玉'))calm+=2;state.demon=clamp(state.demon-calm,0,120);
    return {gain,heal,calm};
  }
  function endTurn() {
    if(state.stats.events===0)return;
    const span=`${state.age}—${state.age+10} 岁`; const practice=decadePractice(); state.age+=10;
    const ended=Math.min(state.eventIndex+(state.result?1:0),state.eventQueue.length);
    const missed=Math.max(0,state.eventQueue.length-ended);
    state.history.unshift({age:state.age,title:'十年闭关',choice:'吐纳周天',success:true,notes:[`修为 +${practice.gain}`,`气血 +${practice.heal}`,`心魔 -${practice.calm}`]});
    if(missed)state.turnLogs.push(`你放下 ${missed} 桩未至的因缘，选择结束这十年。`);
    if(state.age>=state.lifeSpan) { if(state.skills.includes('玄龟息')&&!state.buffs.includes('龟息已用')){state.buffs.push('龟息已用');state.lifeSpan+=12;toast('玄龟息为你续得十二年残喘','good');}else{showEnding('寿元耗尽','你在一次寻常吐纳后没有再睁眼。大道未成，岁月先至。','death');return;} }
    const before=state.before;
    const deltas=[['修为',state.xp-before.xp],['气血',state.hp-before.hp],['寿元上限',state.lifeSpan-before.lifeSpan],['心魔',state.demon-before.demon],['业障',state.karma-before.karma]].filter(x=>x[1]);
    modalRoot.innerHTML=`<div class="modal-backdrop"><section class="modal summary-modal"><button class="modal-x" data-act="close-summary">×</button><p class="eyebrow dark">十年过场 · 第 ${state.turn} 回合</p><h2>${span}</h2><div class="summary-ink"></div>
      <div class="summary-list">${state.turnLogs.slice(0,4).map(x=>`<p><span>◆</span>${esc(x)}</p>`).join('')||'<p>此十年山中无大事，唯松声与吐纳相伴。</p>'}</div>
      <div class="delta-row">${deltas.map(([n,v])=>`<span class="${v<0?'bad':'good'}"><small>${n}</small><b>${v>0?'+':''}${v}</b></span>`).join('')}</div>
      <button class="primary-btn wide" data-act="close-summary">翻过此页</button></section></div>`;
    ping('soft');
  }

  function afterSummary() {
    modalRoot.innerHTML='';
    if(state.age>=360&&state.realm>=6&&state.allies>=4){toast('你已具备开宗立派、成就一方老祖的资格','good');}
    if(state.xp>=realm().need && state.realm<9) showBreakthrough(); else beginTurn();
  }
  function breakChance(mode) {
    let c=34+state.attrs.gengu*3+state.attrs.daoxin*3+state.attrs.qiyun*.8-state.realm*7;
    if(sectMeta().id==='qingxuan')c+=4;if(rootMeta().id==='lei'&&state.realm===8)c+=10;
    if(state.skills.includes('一气化三清'))c+=6;if(state.skills.includes('五雷正法')&&state.realm===8)c+=8;
    if(state.skills.includes('雷帝真经')&&state.realm===8)c+=12;if(state.artifacts.includes('避雷珠')&&state.realm===8)c+=10;
    if(state.artifacts.includes('登仙令')&&state.realm===8)c+=8;if(state.buffs.includes('化劫'))c+=12;
    c-=Math.max(0,state.demon-35)*.25;c-=Math.max(0,state.karma-55)*.18;
    if(mode==='steady')c+=9;if(mode==='bold')c-=6;
    return Math.round(clamp(c,8,94));
  }
  function showBreakthrough() {
    const final=state.realm===8;
    modalRoot.innerHTML=`<div class="modal-backdrop breakthrough-bg"><section class="modal break-modal"><p class="eyebrow">${final?'最终天劫':'境界关隘'} · ${realm().name}</p><span class="trib-glyph">${final?'劫':'破'}</span><h2>${final?'天门在雷海之后':'修为已满，可叩下一境'}</h2><p>${final?'此劫若过，便不再是人间修士。若败，道果与性命皆可能化灰。':'突破并非只看修为。根骨承载，道心掌舵，心魔与业障都会在关前索债。'}</p>
      <div class="break-choices">
        <button data-act="break" data-mode="steady"><span>循序叩关</span><b>${breakChance('steady')}%</b><small>较稳 · 失败代价较轻</small></button>
        <button data-act="break" data-mode="bold"><span>破釜冲关</span><b>${breakChance('bold')}%</b><small>凶险 · 成功额外淬炼属性</small></button>
      </div>${final?'':'<button class="text-btn center" data-act="break" data-mode="wait">暂缓突破，继续积累</button>'}</section></div>`;
  }
  function attemptBreak(mode) {
    if(mode==='wait'){modalRoot.innerHTML='';beginTurn();return;}
    const final=state.realm===8,chance=breakChance(mode),ok=Math.random()*100<chance;
    state.buffs=state.buffs.filter(x=>x!=='化劫');
    if(ok){
      const need=realm().need;state.xp=Math.max(0,state.xp-need);state.realm++;state.stats.breaks++;
      const lifeGain=D.REALMS[state.realm].life||0;state.lifeSpan+=lifeGain;
      const key=rand(Object.keys(state.attrs));state.attrs[key]++;
      if(mode==='bold'){const key2=rand(Object.keys(state.attrs));state.attrs[key2]++;}
      state.maxHp+=5;state.hp=Math.min(state.maxHp,state.hp+20);state.demon=Math.max(0,state.demon-6);
      ping('success'); modalRoot.innerHTML='';
      if(final||state.realm>=9){
        if(state.karma>=72&&state.attrs.shafa>=11)showEnding('魔道至尊','你没有叩开天门，而是将天门连同守门仙人一并炼入血海。三界自此多了一位不受天条约束的至尊。','magic');
        else showEnding('白日飞升','九重雷海尽散，凡尘在脚下缩作一粒微尘。你终于以此生之道，叩开了真正的天门。','win');
      } else {const cue={type:'breakthrough',glyph:'破',kicker:'天地共鸣',label:`踏入${realm().name}`};toast(`破境成功：踏入${realm().name}，寿元 +${lifeGain}`,'good');beginTurn();setTimeout(()=>showRewardFx(cue),40);}
    } else {
      let damage=mode==='bold'?38:23;if(state.skills.includes('九转金身'))damage=Math.round(damage*.82);if(state.artifacts.includes('玄黄塔'))damage-=10;
      state.hp=Math.max(0,state.hp-damage);state.demon=clamp(state.demon+(mode==='bold'?18:10),0,120);state.lifeSpan-=mode==='bold'?10:5;
      ping('danger');modalRoot.innerHTML='';
      if(final){
        if(state.attrs.tipo+state.attrs.gengu>=22&&state.lifeSpan-state.age>=35)showEnding('兵解散仙','天劫毁去道基，却没能毁去肉身。你从雷海中爬出，不入仙籍，自成散仙。','alt');
        else showEnding('渡劫陨落','最后一道天雷将道果、肉身与名字一并抹去。云海沉默，仿佛你从未来过。','death');
      } else if(!checkImmediateEnd()){toast('突破失败：经脉受创，心魔滋长','bad');beginTurn();setTimeout(()=>showRewardFx({type:'injury',glyph:'伤',kicker:'破境反噬',label:'经脉受创'}),40);}
    }
  }

  function statusPanel() {
    const rem=Math.max(0,state.lifeSpan-state.age),need=realm().need||1,progress=state.realm>=9?100:clamp(state.xp/need*100,0,100);
    return `<aside class="status-panel">
      <div class="identity"><span class="avatar-seal">${pathMeta().icon}</span><div><small>${sectMeta().name}</small><b>${realm().name} · ${pathMeta().name}</b></div><button data-act="toggle-stats" aria-label="展开属性">十维</button></div>
      <div class="vitals">
        <div><span>修为 ${state.xp} / ${state.realm>=9?'—':need}</span><i><b style="width:${progress}%"></b></i></div>
        <div><span>气血 ${state.hp} / ${state.maxHp}</span><i class="blood"><b style="width:${clamp(state.hp/state.maxHp*100,0,100)}%"></b></i></div>
      </div>
      <div class="status-chips"><span><small>年龄 / 尚余</small><b>${state.age} / ${rem} 年</b></span><span class="${state.demon>=65?'danger':''}"><small>心魔</small><b>${state.demon}</b></span><span class="${state.karma>=65?'danger':''}"><small>业障</small><b>${state.karma}</b></span><span><small>气运</small><b>${state.attrs.qiyun}</b></span></div>
      <div class="mini-attrs" id="mini-attrs">${D.ATTRS.map(a=>`<span title="${a.desc}"><i>${a.icon}</i>${a.name}<b>${state.attrs[a.key]}</b></span>`).join('')}</div>
      <blockquote><b>宗门命法</b>${sectMeta().passive}</blockquote>
      ${state.age>=360&&state.realm>=6&&state.allies>=4?'<button class="ancestor-btn" data-act="ancestor">立下道统 · 成就一方老祖</button>':''}
    </aside>`;
  }

  function eventPanel() {
    const event=currentEvent();
    if(!event) return `<article class="event-card finished"><span class="event-seal">终</span><p class="eyebrow dark">本回合因缘已尽</p><h2>十年无事，可以翻篇</h2><p>闭关吐纳会额外获得修为、恢复气血并压制少量心魔。</p><button class="primary-btn wide" data-act="end-turn">结束此十年</button></article>`;
    const solved=!!state.result;
    return `<article class="event-card">
      <div class="event-art art-${event.art}"><div class="art-dust">${Array.from({length:9},(_,i)=>`<i style="--i:${i}"></i>`).join('')}</div><div class="event-year">${state.age} 岁 · 第 ${state.turn} 个十年</div><span>${event.tier===0?'尘':event.tier===1?'云':'天'}</span><small>${state.eventIndex+1} / ${state.eventQueue.length}</small></div>
      <div class="event-copy ${solved?`result-copy ${state.result.success?'result-success':'result-failure'}`:''}"><p class="eyebrow dark">${solved?`事件结果 · ${state.result.success?'吉':'凶'}`:`随机事件 · ${event.tier===0?'人间因缘':event.tier===1?'云海奇遇':'天外大劫'}`}</p><h2>${esc(event.title.replace(/^.*·/,''))}</h2><p>${esc(solved?state.result.narrative:event.desc)}</p></div>
      ${solved?`<div class="outcome ${state.result.success?'success':'failure'} cue-${state.result.cue.type}"><span>${state.result.cue.glyph}</span><div><small class="outcome-kicker">${esc(state.result.cue.kicker)}</small><h3>${esc(state.result.cue.label)}</h3><p>${state.result.notes.map(esc).join(' · ')}</p><small>此选项判定率 ${state.result.chance}%</small></div></div>
        <div class="post-actions">${state.eventIndex+1<state.eventQueue.length?'<button class="ink-btn" data-act="continue">迎接下一桩因缘</button>':''}${state.eventIndex>=1?'<button class="primary-btn" data-act="end-turn">结束此十年</button>':''}</div>`:
      `<div class="option-list">${event.options.map((o,i)=>{const c=chanceFor(event,o),omen=optionOmen(o);return `<button class="event-option omen-${omen.type}" data-act="pick" data-index="${i}"><span class="option-letter">${['甲','乙','丙'][i]}</span><span><b>${esc(o.label)}</b><small>${esc(o.hint)} · ${riskLabel(c)}</small></span><i class="option-omen">${omen.glyph}</i><em>${o.safe?'安稳':c+'%'}</em></button>`}).join('')}</div>
      <div class="event-tools"><button data-act="scry" ${state.scry<=0?'disabled':''}>推演天机 <small>余 ${state.scry} 次 · 折寿 ${sectMeta().id==='sanxiu'?3:6} 年</small></button><span>判定率已公开，命数与功法会共同修正</span></div>`}
    </article>`;
  }

  function renderGame() {
    app.innerHTML=`<section class="game-screen scene-${currentEvent()?.art||'spirit'}">
      <header class="game-topbar"><button class="brand" data-act="home"><span>修</span><b>修仙之路</b></button><div class="realm-road">${D.REALMS.slice(0,9).map((r,i)=>`<i class="${i<state.realm?'done':i===state.realm?'now':''}" title="${r.name}"></i>`).join('')}</div><div class="top-actions"><button data-act="inventory">行囊 <em>${state.skills.length+state.artifacts.length+state.pills.length}</em></button><button data-act="help">?</button><button class="${soundOn?'music-live':''}" data-act="sound" aria-label="切换古风音乐">${soundOn?'♫':'静'}</button></div></header>
      <div class="game-layout">${statusPanel()}<main class="stage">${eventPanel()}<div class="turn-marks">${state.eventQueue.map((_,i)=>`<i class="${i<state.eventIndex||(i===state.eventIndex&&state.result)?'done':i===state.eventIndex?'now':''}"></i>`).join('')}</div></main>
      <aside class="chronicle"><div class="chronicle-head"><span>命册</span><b>最近因果</b></div>${state.history.slice(0,6).map(h=>`<div class="history-item ${h.success?'':'bad'}"><span>${h.age}岁</span><div><b>${esc(h.title.replace(/^.*·/,''))}</b><small>${esc(h.choice)}</small></div></div>`).join('')||'<p class="empty">此页尚空。<br>你的一生将由选择写就。</p>'}<div class="difficulty-note"><b>天道无情</b><p>凶险选择收益更高，但失败会留下真实后果。先看属性，再看代价。</p></div></aside></div>
      <nav class="mobile-nav"><button data-act="toggle-stats">命数</button><button data-act="inventory">行囊</button><button data-act="help">天道</button></nav>
    </section>`;
  }

  function renderInventory() {
    const pillRows=state.pills.length?state.pills.map((name,i)=>{const p=pillMeta(name);return `<div class="item-row"><span class="item-icon pill">丹</span><div><b>${name}</b><small>${p?.desc||''}</small></div><button data-act="use-pill" data-index="${i}">服用</button></div>`}).join(''):'<p class="empty-line">丹匣空空。</p>';
    modalRoot.innerHTML=`<div class="modal-backdrop"><section class="modal inventory-modal"><button class="modal-x" data-act="close-modal">×</button><p class="eyebrow dark">随身行囊</p><h2>功法 · 法宝 · 丹药</h2>
      <div class="tabs-content"><h3>功法 <em>${state.skills.length}/12</em></h3>${state.skills.map(name=>{const x=skillMeta(name)||{type:'奇法',desc:'此法来历不明。'};return `<div class="item-row"><span class="item-icon">法</span><div><b>${name}</b><small>${x.type} · ${x.desc}</small></div></div>`}).join('')}
      <h3>法宝 <em>${state.artifacts.length}/8</em></h3>${state.artifacts.length?state.artifacts.map(name=>{const x=artifactMeta(name)||{type:'异宝',desc:'来历不明。'};return `<div class="item-row"><span class="item-icon treasure">宝</span><div><b>${name}</b><small>${x.type} · ${x.desc}</small></div></div>`}).join(''):'<p class="empty-line">尚无法宝认主。</p>'}
      <h3>丹药 <em>${state.pills.length}</em></h3>${pillRows}</div>
      <div class="insight-box"><div><b>悟道点 ${state.skillPoints}</b><small>可直接补强十维命数，弥补短板。</small></div><button data-act="train-open" ${state.skillPoints<=0?'disabled':''}>悟道加点</button></div></section></div>`;
  }
  function renderTraining() {
    modalRoot.innerHTML=`<div class="modal-backdrop"><section class="modal train-modal"><button class="modal-x" data-act="close-modal">×</button><p class="eyebrow dark">返照命宫</p><h2>悟道加点 <em>余 ${state.skillPoints}</em></h2><div class="train-grid">${D.ATTRS.map(a=>`<button data-act="train-add" data-key="${a.key}" ${state.skillPoints<=0?'disabled':''}><span>${a.icon}</span><b>${a.name}</b><em>${state.attrs[a.key]}</em><small>${a.desc}</small></button>`).join('')}</div></section></div>`;
  }
  function usePill(index) {
    const name=state.pills[index],p=pillMeta(name);if(!p)return;const e=p.effect||{};const mult=sectMeta().id==='baicao'?1.4:1;
    if(e.hp)state.hp=clamp(state.hp+Math.round(e.hp*mult),0,state.maxHp);if(e.life)state.lifeSpan+=Math.round(e.life*mult);if(e.demon)state.demon=clamp(state.demon+Math.round(e.demon*mult),0,120);if(e.xp)state.xp+=Math.round(e.xp*mult);
    if(e.attr)state.attrs[e.attr]+=(e.stat||1);if(e.all)Object.keys(state.attrs).forEach(k=>state.attrs[k]++);if(e.stat&&!e.attr&&!e.all){const k=rand(Object.keys(state.attrs));state.attrs[k]+=e.stat;}
    if(e.buff)addUnique(state.buffs,e.buff);state.pills.splice(index,1);ping('success');toast(`服下${name}：${p.desc}`,'good');renderInventory();setTimeout(()=>showRewardFx({type:'pill',glyph:'丹',kicker:'丹气入脉',label:name}),30);
  }

  function showHelp() {
    modalRoot.innerHTML=`<div class="modal-backdrop"><section class="modal help-modal"><button class="modal-x" data-act="close-modal">×</button><p class="eyebrow dark">天道卷宗</p><h2>如何活得更久</h2>
      <div class="help-grid"><div><span>壹</span><h3>先看判定率</h3><p>每个选项公开大致成功率。十维命数、主修、门派、功法、法宝、人脉和仇敌都会修正它。</p></div><div><span>贰</span><h3>别只堆一项</h3><p>高收益选项常检验不同属性。最低属性也会在秘境和心魔事件中被点名。</p></div><div><span>叁</span><h3>寿元不是血条</h3><p>年龄达到寿元上限即坐化。丹药、境界突破和木灵根可续命；推演天机会折寿。</p></div><div><span>肆</span><h3>飞升不是唯一结局</h3><p>渡过最终天劫可飞升。肉身承劫可能转为散仙；高业障可染指魔尊；久居高境还能立道为祖。</p></div></div>
      <div class="death-list"><b>常见死法</b><span>气血归零 · 战死</span><span>心魔达到 100 · 走火入魔</span><span>年龄抵达寿元 · 坐化</span><span>最终天劫失败 · 陨落或兵解</span></div>
      <p class="help-foot">内容：${D.SECTS.length} 门派 · ${D.PATHS.length} 流派 · ${D.ATTRS.length} 维属性 · ${D.EVENTS.length} 事件变体 · ${D.SKILLS.length} 功法 · ${D.ARTIFACTS.length} 法宝 · ${D.PILLS.length} 丹药</p></section></div>`;
  }

  function showEnding(title,desc,type) {
    view='ending';const years=state?state.age-16:0;const isWin=type==='win'||type==='magic';
    app.innerHTML=`<section class="ending-screen ending-${type}"><div class="ending-mountains"></div><div class="ending-card"><p class="eyebrow">${isWin?'大道已成':type==='alt'?'别样道果':'此生已尽'}</p><span class="ending-seal">${isWin?'仙':type==='alt'?'散':'终'}</span><h1>${esc(title)}</h1><p>${esc(desc)}</p>
      <div class="life-stats"><span><small>享年</small><b>${state.age}</b></span><span><small>修行</small><b>${years}年</b></span><span><small>境界</small><b>${realm().name}</b></span><span><small>历劫</small><b>${state.stats.events}</b></span></div>
      <div class="epitaph"><b>命册批语</b><p>${state.stats.success>=state.stats.fail*2?'善观天时，亦敢逆命。':state.karma>65?'杀劫满身，终与天争。':state.demon>65?'求道太急，心火自焚。':'大道漫长，此生已尽其力。'}</p></div>
      <div class="ending-actions"><button class="primary-btn" data-act="restart">再入轮回</button><button class="ink-btn light" data-act="copy">复制战绩</button></div><p class="quiet">没有存档，也没有回头路。下一世会遇见新的命数。</p></div></section>`;
    modalRoot.innerHTML='';ping(isWin?'success':'danger');setTimeout(()=>showRewardFx(isWin?{type:'breakthrough',glyph:'仙',kicker:'天门洞开',label:title}:type==='alt'?{type:'fortune',glyph:'道',kicker:'别样道果',label:title}:{type:'injury',glyph:'终',kicker:'此生已尽',label:title}),120);
  }
  function ancestorEnding(){showEnding('一方老祖','你不再追逐那扇遥远天门，而是在此界开宗立派。千年后，你的名字成了无数修士踏上仙途时读到的第一行字。','alt');}
  function copyResult(){const text=`《修仙之路》战绩：${state.age}岁，${realm().name}·${pathMeta().name}，历经${state.stats.events}劫——${document.querySelector('.ending-card h1')?.textContent||'道途未尽'}。`;navigator.clipboard?.writeText(text).then(()=>toast('战绩已复制，可发到群里','good')).catch(()=>toast(text));}

  function render(){if(view==='title')renderTitle();else if(view==='create')renderCreation();else if(view==='game')renderGame();}

  document.addEventListener('click',e=>{
    const el=e.target.closest('[data-act]');if(!el||el.disabled)return;const act=el.dataset.act;
    if(act==='begin'){view='create';startMusic();render();ping();}
    else if(act==='home'){if(view==='game'&&state&&!confirm('离开将失去本局全部进度，确定重开吗？'))return;view='title';state=null;modalRoot.innerHTML='';render();}
    else if(act.startsWith('select-')){const type=act.split('-')[1];draft[type]=Number(el.dataset.index);render();ping();}
    else if(act==='stat-plus'){const k=el.dataset.key;if(draft.points>0&&draft.attrs[k]<8){draft.attrs[k]++;draft.points--;render();}}
    else if(act==='stat-minus'){const k=el.dataset.key;if(draft.attrs[k]>1){draft.attrs[k]--;draft.points++;render();}}
    else if(act==='start')startGame();
    else if(act==='pick')resolveOption(Number(el.dataset.index));
    else if(act==='continue')continueEvent();
    else if(act==='end-turn')endTurn();
    else if(act==='scry')scry();
    else if(act==='close-summary')afterSummary();
    else if(act==='break')attemptBreak(el.dataset.mode);
    else if(act==='inventory')renderInventory();
    else if(act==='help')showHelp();
    else if(act==='close-modal')modalRoot.innerHTML='';
    else if(act==='use-pill')usePill(Number(el.dataset.index));
    else if(act==='train-open')renderTraining();
    else if(act==='train-add'){if(state.skillPoints>0){state.attrs[el.dataset.key]++;state.skillPoints--;ping();renderTraining();}}
    else if(act==='toggle-stats'){document.querySelector('.status-panel')?.classList.toggle('mobile-open');}
    else if(act==='sound')toggleSound();
    else if(act==='restart'){draft={sect:0,root:0,path:0,points:24,attrs:Object.fromEntries(D.ATTRS.map(a=>[a.key,2]))};view='create';state=null;render();}
    else if(act==='copy')copyResult();
    else if(act==='ancestor')ancestorEnding();
  });
  render();
})();
