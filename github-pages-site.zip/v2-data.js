(function () {
  'use strict';

  const legacy = window.GAME_DATA || {};
  const attr = (key, name, icon, desc) => ({ key, name, icon, desc });
  const ATTRS = [
    attr('gengu', '根骨', '骨', '修炼根基、突破与寿元'),
    attr('wuxing', '悟性', '悟', '参悟功法与识破机缘'),
    attr('tipo', '体魄', '体', '气血、负伤与肉身考验'),
    attr('lingli', '灵力', '灵', '吐纳修为与术法威能'),
    attr('shenshi', '神识', '识', '感知、破幻与炼丹'),
    attr('daoxin', '道心', '心', '抵御心魔与渡劫'),
    attr('shenfa', '身法', '影', '逃脱、先手与探索'),
    attr('meili', '魅力', '缘', '交涉、宗门与人物关系'),
    attr('shafa', '杀伐', '杀', '搏杀、威慑与魔道'),
    attr('qiyun', '气运', '运', '机缘、掉落与避祸')
  ];

  const PATHS = [
    {id:'sword',name:'剑修',icon:'剑',attrs:['wuxing','daoxin'],affinity:'sword',skill:'青霄剑诀',desc:'一剑破万法，爆发与悟道并重。'},
    {id:'blade',name:'刀修',icon:'刀',attrs:['shafa','tipo'],affinity:'blade',skill:'断岳刀经',desc:'以战养战，胜负皆有代价。'},
    {id:'staff',name:'棍修',icon:'棍',attrs:['tipo','gengu'],affinity:'staff',skill:'伏魔棍典',desc:'守中带攻，最善恶战久持。'},
    {id:'spear',name:'枪修',icon:'枪',attrs:['shenfa','shafa'],affinity:'spear',skill:'惊龙枪谱',desc:'先手如雷，愈战愈勇。'},
    {id:'fist',name:'拳修',icon:'拳',attrs:['tipo','daoxin'],affinity:'fist',skill:'撼山拳意',desc:'拳意通神，近身无双。'},
    {id:'qi',name:'气修',icon:'气',attrs:['lingli','gengu'],affinity:'focus',skill:'太虚吐纳法',desc:'周天不息，积少成多。'},
    {id:'spell',name:'法修',icon:'法',attrs:['lingli','shenshi'],affinity:'focus',skill:'五雷正法',desc:'术法万象，后期强横。'},
    {id:'talisman',name:'符修',icon:'符',attrs:['shenshi','wuxing'],affinity:'talisman',skill:'玄门符箓',desc:'预先布局，以弱胜强。'},
    {id:'alchemy',name:'丹修',icon:'丹',attrs:['shenshi','qiyun'],affinity:'alchemy',skill:'百草丹录',desc:'借丹续命，化腐为奇。'},
    {id:'forge',name:'器修',icon:'器',attrs:['gengu','shenshi'],affinity:'forge',skill:'天工炼器篇',desc:'百器随心，以物证道。'},
    {id:'body',name:'体修',icon:'体',attrs:['tipo','gengu'],affinity:'body',skill:'八荒炼体诀',desc:'肉身成圣，硬撼天劫。'},
    {id:'demon',name:'魔修',icon:'魔',attrs:['shafa','lingli'],affinity:'demon',skill:'血海魔功',desc:'夺天逆命，收益与反噬并存。'},
    {id:'wanderer',name:'散修',icon:'游',attrs:['qiyun','shenfa'],affinity:'wanderer',skill:'万象杂篇',desc:'天地为师，不拘一法。'}
  ];

  const SECTS = (legacy.SECTS || []).map((s) => ({...s}));
  const ROOTS = [
    {id:'jin',name:'金灵根',tone:'金',mods:{sword:3,blade:2},rarity:'寻常'},
    {id:'mu',name:'木灵根',tone:'木',mods:{alchemy:3,body:1},rarity:'寻常'},
    {id:'shui',name:'水灵根',tone:'水',mods:{focus:3,talisman:1},rarity:'寻常'},
    {id:'huo',name:'火灵根',tone:'火',mods:{blade:3,forge:2},rarity:'寻常'},
    {id:'tu',name:'土灵根',tone:'土',mods:{body:3,staff:2},rarity:'寻常'},
    {id:'dual',name:'水木双灵根',tone:'双',mods:{alchemy:2,focus:2},rarity:'良品'},
    {id:'triple',name:'金火土三灵根',tone:'三',mods:{sword:1,blade:1,body:1},rarity:'驳杂'},
    {id:'five',name:'五灵根',tone:'杂',mods:{wanderer:2},rarity:'驳杂'},
    {id:'feng',name:'变异风灵根',tone:'风',mods:{spear:3,sword:2},rarity:'稀有'},
    {id:'lei',name:'变异雷灵根',tone:'雷',mods:{focus:4,forge:1},rarity:'稀有'},
    {id:'ice',name:'变异冰灵根',tone:'冰',mods:{talisman:3,sword:2},rarity:'稀有'},
    {id:'shadow',name:'幽冥灵根',tone:'幽',mods:{demon:4},rarity:'异数'}
  ];

  const REALMS = legacy.REALMS || [
    {name:'凡躯',need:55,life:0},{name:'炼气',need:95,life:18},{name:'筑基',need:155,life:28},
    {name:'金丹',need:250,life:45},{name:'元婴',need:390,life:65},{name:'化神',need:590,life:85},
    {name:'炼虚',need:850,life:110},{name:'合体',need:1180,life:140},{name:'渡劫',need:1550,life:0},{name:'飞升',need:0,life:0}
  ];

  const NPCS = [
    {id:'guchangge',name:'顾长歌',gender:'男',age:19,portrait:'assets/images/characters/guchangge.webp',sect:'青玄剑宗',role:'宿命竞争者',personality:'骄傲守诺',realm:'炼气',intro:'青衣负剑，目光像未出鞘的锋。'},
    {id:'shenqingshuang',name:'沈清霜',gender:'女',age:18,portrait:'assets/images/characters/shenqingshuang.webp',sect:'百草丹谷',role:'医修与同行者',personality:'清冷仁善',realm:'炼气',intro:'衣上有淡淡药香，说话总留三分余地。'},
    {id:'shenwanshan',name:'沈万山',gender:'男',age:28,portrait:'assets/images/characters/shenwanshan.webp',sect:'万宝商会',role:'云游商人',personality:'圆融重诺',realm:'凡人',intro:'一辆旧木车、两串铜铃，他却总能拿出你需要之物。'},
    {id:'luchenzhou',name:'陆沉舟',gender:'男',age:83,portrait:'assets/images/characters/luchenzhou.webp',sect:'青玄剑宗',role:'剑宗长老',personality:'严厉公正',realm:'金丹',intro:'白鬓如霜，袖中剑意压得云气低垂。'},
    {id:'wuxuanzi',name:'乌玄子',gender:'男',age:167,portrait:'assets/images/characters/wuxuanzi.webp',sect:'无相魔宗',role:'魔修老道',personality:'诡谲惜才',realm:'元婴',intro:'黑袍老者笑时，身后的影子却从不笑。'},
    {id:'weiqingluo',name:'魏青萝',gender:'女',age:24,portrait:'assets/images/characters/weiqingluo.webp',sect:'云游散修',role:'黑市商人',personality:'大胆狡黠',realm:'筑基',intro:'青伞遮面，袖中藏着半座黑市的秘密。'},
    {id:'yezhiqiu',name:'叶知秋',gender:'女',age:20,portrait:'assets/images/characters/yezhiqiu.webp',sect:'太虚气府',role:'长期好友',personality:'洒脱敏锐',realm:'炼气',intro:'腰间挂酒葫芦，能在笑声里看穿谎话。'},
    {id:'shiwujie',name:'石无极',gender:'男',age:340,portrait:'assets/images/characters/shiwujie.webp',sect:'上古体宗',role:'体修残魂',personality:'豪迈执拗',realm:'残魂',intro:'残魂如山岳，胸前仍留着天劫烧出的裂纹。'},
    {id:'mowenchen',name:'莫问尘',gender:'男',age:36,portrait:'assets/images/characters/mowenchen.webp',sect:'无门无派',role:'隐藏散修师父',personality:'懒散通透',realm:'金丹',intro:'破衣草履，手中枯枝却能点落星光。'},
    {id:'ningwuya',name:'宁无涯',gender:'女',age:29,portrait:'assets/images/characters/ningwuya.webp',sect:'幽都黑市',role:'情报商',personality:'冷静逐利',realm:'筑基',intro:'半张银面映着烛火，交易从来只谈等价。'},
    {id:'peixuanzhen',name:'裴玄真',gender:'女',age:96,portrait:'assets/images/characters/peixuanzhen.webp',sect:'百草丹谷',role:'丹师长老',personality:'温和果断',realm:'金丹',intro:'指尖常染药色，救人与杀人只差一味药。'},
    {id:'tianyandaojun',name:'天衍道君',gender:'无',age:9999,portrait:'assets/images/characters/tianyandaojun.webp',sect:'天道',role:'最终天道使者',personality:'无情守序',realm:'未知',intro:'面容在云雷间不断变化，像众生又不像任何人。'}
  ];

  const effect = (e) => e;
  const choice = (label, risk, effects, nextNode=null, requirement=null, successText='', failText='') => ({label,risk,effects,nextNode,requirement,successText,failText});
  const node = (nodeId,title,image,description,choices,music='mortal',soundEffect='choice') => ({nodeId,title,image,music,soundEffect,description,choices});
  const chain = (eventId,title,phase,yearRange,weight,cooldown,nodes,extra={}) => ({eventId,chainId:eventId,title,phase,yearRange,weight,cooldown,nodes,unique:true,...extra});

  const MORTAL_CHAINS = [
    chain('mortal_home','柴门初雪','mortal',[1,1],20,99,[
      node('start','柴门初雪','assets/images/scenes/humble-home.webp','十岁那年，大雪压垮屋檐。病中的母亲把仅有的六两银子塞到你手中。',[choice('请郎中上门','稳妥',{silver:-5,health:8,karma:2,flags:['savedMother']},'doctor',null,'郎中来得及时，母亲的咳声终于平息。','') ,choice('独自进山采药','冒险',{check:{attr:'tipo',difficulty:7},silver:2,health:-8,rootHint:{mu:2},affinity:{alchemy:1}},'mountain',null,'你在雪下认出止咳草，冻伤却也落在指尖。','山风几乎将你冻僵，背回的草药也认错了。'),choice('留下修屋','稳妥',{silver:1,gengu:1},'roof',null,'你以肩顶梁，从木纹里学会与重量相处。','')]),
      node('doctor','郎中的药箱','assets/images/scenes/county-clinic.webp','郎中临走前发现你对药香极敏锐，问你是否愿意替他抄药方。',[choice('认真抄录','稳妥',{wuxing:1,affinity:{alchemy:2},flags:['learnedHerbs'],silver:2},null,null,'三日抄录让你记住了第一百味凡草。',''),choice('婉拒去练拳','稳妥',{tipo:1,affinity:{fist:2}},null)]),
      node('mountain','雪下青芽','assets/images/scenes/cliff-cave.webp','崖边青芽旁有一道细小足印，通往被雪封住的石缝。',[choice('钻入石缝','凶险',{check:{attr:'shenfa',difficulty:8},item:'残缺吐纳诀',lingli:1,flags:['metOldTaoist'],npc:{id:'mowenchen',relation:5}},null,null,'石缝后不是野兽巢穴，而是一位装睡的落魄道人。','石缝骤然塌落，你被碎石划伤，只抢出半页旧纸。'),choice('带药回家','稳妥',{karma:2,health:5,rootHint:{mu:1}},null)]),
      node('roof','屋脊星光','assets/images/scenes/stargazing.webp','修好屋顶那夜，你第一次看见山巅有一道光逆着雪飞上云端。',[choice('记住那道光','未知',{daoxin:1,flags:['yearnedImmortal']},null),choice('回屋睡觉','稳妥',{health:3},null)])
    ]),
    chain('mortal_grove','桃林狐踪','mortal',[2,2],20,99,[
      node('start','桃林狐踪','assets/images/scenes/peach-grove.webp','早春桃林里，一只受伤白狐被猎夹困住，猎户的脚步已在坡下。',[choice('放走白狐','冒险',{karma:3,qiyun:1,flags:['savedFox'],rootHint:{mu:1},npc:{id:'yezhiqiu',relation:2}},'fox'),choice('交给猎户','稳妥',{silver:4,karma:-1,affinity:{bow:1}},'hunter'),choice('取狐血炼体','凶险',{check:{attr:'shafa',difficulty:8},tipo:2,sin:4,flags:['foxBlood']},null,null,'狐血如火，短暂地强化了肉身。','白狐反咬手腕，腥甜妖气自此缠上了你。')],'mortal','monster'),
      node('fox','白毛与桃花','assets/images/scenes/peach-grove.webp','白狐没有逃远，只在林边回望。它将一枚温热桃核推到你脚边。',[choice('收下桃核','稳妥',{item:'灵桃核',qiyun:1,rootHint:{mu:2},future:{year:52,eventId:'jade_echo'}},null),choice('埋回土中','未知',{karma:2,flags:['buriedPeach']},null)]),
      node('hunter','猎户的叹息','assets/images/scenes/beast-attack.webp','猎户认出这是有灵性的白狐，握刀的手迟疑起来。',[choice('劝他也放生','稳妥',{check:{attr:'meili',difficulty:6},karma:2,meili:1},null,null,'猎户收起刀，把银钱也留给了你。','猎户觉得你反复无常，带狐离去。'),choice('拿钱离开','稳妥',{silver:2},null)])
    ]),
    chain('mortal_market','县集见闻','mortal',[3,3],20,99,[
      node('start','县集见闻','assets/images/scenes/county-market.webp','县集人声鼎沸。落魄商人沈万山的货箱散了一地，几个泼皮正踩着他的账册。',[choice('替他解围','冒险',{check:{attr:'tipo',difficulty:7},silver:2,karma:2,npc:{id:'shenwanshan',relation:12},flags:['helpedMerchant']},'shop',null,'你逼退泼皮，沈万山将名字郑重记在账册上。','你挨了几棍，仍替他保住了最重要的货箱。'),choice('借他二十两','未知',{requireCurrency:{silver:20},silver:-20,npc:{id:'shenwanshan',relation:20},flags:['lentMerchant']},'shop'),choice('趁乱摸走货物','凶险',{item:'来历不明的铜铃',sin:3,npc:{id:'shenwanshan',relation:-12},flags:['robbedMerchant']},null)]),
      node('shop','一卷旧书','assets/images/scenes/county-market.webp','沈万山让你从余货中选一样：旧剑谱、药草册，或一块看不出用途的黑铁。',[choice('旧剑谱','稳妥',{affinity:{sword:3},wuxing:1,item:'残剑图谱'},null),choice('药草册','稳妥',{affinity:{alchemy:3},shenshi:1,item:'百草手记'},null),choice('神秘黑铁','未知',{affinity:{forge:3},item:'天外黑铁',rootHint:{lei:1}},null)])
    ]),
    chain('mortal_forge','炉火照夜','mortal',[4,4],20,99,[
      node('start','炉火照夜','assets/images/scenes/blacksmith.webp','铁匠铺缺一个拉风箱的人。老铁匠许诺让你亲手碰一件兵器。',[choice('拉满一夜风箱','冒险',{check:{attr:'tipo',difficulty:8},gengu:1,tipo:1,silver:3},'weapons',null,'汗水落在炉边化成白汽，你撑到了天亮。','你脱力倒下，掌心留下烫伤。'),choice('观察淬火','稳妥',{wuxing:1,affinity:{forge:2},rootHint:{huo:1}},'weapons'),choice('偷拿桌上的符纸','凶险',{affinity:{talisman:2},sin:2,flags:['stoleTalisman']},null)]),
      node('weapons','百兵低鸣','assets/images/scenes/blacksmith.webp','老铁匠掀开布帘，剑、刀、棍、枪并列墙上。你只能选一件试手。',[choice('试剑','稳妥',{affinity:{sword:4},item:'青锋木剑'},null),choice('试刀','稳妥',{affinity:{blade:4},item:'厚背柴刀'},null),choice('试棍','稳妥',{affinity:{staff:4},item:'铁木长棍'},null),choice('试枪','稳妥',{affinity:{spear:4},item:'白蜡木枪'},null)])
    ]),
    chain('mortal_beast','黑风入村','mortal',[5,5],20,99,[
      node('start','黑风入村','assets/images/scenes/beast-attack.webp','半夜犬吠齐止，一头额生黑角的山彘撞破村门。',[choice('正面挡住','凶险',{check:{attr:'tipo',difficulty:11},health:-12,shafa:1,affinity:{body:2,fist:2},flags:['foughtBoar']},'aftermath',null,'你以木叉抵住獠牙，村民合力斩下山彘。','獠牙贯伤肋下，你被拖回屋时已看不清灯火。'),choice('引它入陷阱','冒险',{check:{attr:'wuxing',difficulty:9},shenfa:1,qiyun:1,affinity:{spear:2}},'aftermath',null,'山彘坠坑，黑角在月光下闪过灵纹。','陷阱提前崩裂，山彘追得你滚下土坡。'),choice('护送孩童躲藏','稳妥',{karma:3,meili:1,flags:['savedChildren']},'aftermath')]),
      node('aftermath','山彘黑角','assets/images/scenes/beast-attack.webp','山彘死后，黑角仍有微弱雷意。村长问你如何处置。',[choice('研磨入药','冒险',{health:8,rootHint:{lei:3},flags:['touchedThunder']},null),choice('卖给行商','稳妥',{silver:12},null),choice('埋在村口','未知',{karma:2,daoxin:1},null)])
    ]),
    chain('mortal_cave','崖下残洞','mortal',[6,6],20,99,[
      node('start','崖下残洞','assets/images/scenes/cliff-cave.webp','采药时山石滑落，你坠入一座刻满呼吸图的残洞。出口在十丈高处。',[choice('参悟石刻','冒险',{check:{attr:'wuxing',difficulty:10},lingli:2,wuxing:1,affinity:{focus:3},item:'残缺吐纳诀',flags:['learnedBreath']},'exit',null,'呼吸与石纹重合，腹中第一次生出一缕暖流。','石刻杂念太重，你头痛欲裂，只记下一句口诀。'),choice('徒手攀崖','凶险',{check:{attr:'tipo',difficulty:12},tipo:2,health:-10,affinity:{body:2}},'exit',null,'指尖渗血，你却真的爬回了天光下。','碎石再次滑落，旧伤从此遇雨便痛。'),choice('呼救等待','稳妥',{silver:-3,health:3},'exit')]),
      node('exit','洞底残玉','assets/images/scenes/cliff-cave.webp','临走时，你看见一块半月形残玉压在枯骨下。',[choice('取走残玉','未知',{item:'神秘残玉·左',karma:1,future:{year:60,eventId:'jade_echo'},flags:['jadeLeft']},null),choice('替枯骨安葬','稳妥',{karma:3,daoxin:1,flags:['buriedBones']},null)])
    ]),
    chain('mortal_night','观星客','mortal',[7,7],20,99,[
      node('start','观星客','assets/images/scenes/stargazing.webp','陌生少女叶知秋躺在稻草垛上数星星。她说最亮的一颗将在三十年后坠落。',[choice('与她论星','稳妥',{shenshi:1,npc:{id:'yezhiqiu',relation:10},flags:['starPromise'],future:{year:40,eventId:'starfall_world'}},'promise'),choice('说她胡言乱语','稳妥',{npc:{id:'yezhiqiu',relation:-4}},null),choice('问如何修仙','未知',{wuxing:1,affinity:{focus:2},npc:{id:'yezhiqiu',relation:5}},'promise')]),
      node('promise','三十年之约','assets/images/scenes/stargazing.webp','她把一枚刻着星纹的铜钱抛给你：“若你那时还活着，便一起去看。”',[choice('收下约定','稳妥',{item:'星纹铜钱',flags:['starPact'],npc:{id:'yezhiqiu',relation:8}},null),choice('把铜钱还她','稳妥',{daoxin:1,npc:{id:'yezhiqiu',relation:2}},null)])
    ]),
    chain('mortal_taoist','桥下老道','mortal',[8,8],20,99,[
      node('start','桥下老道','assets/images/scenes/wandering-taoist.webp','暴雨中，落魄老道莫问尘睡在桥下，怀里却护着一盏不灭的灯。',[choice('分他干粮','稳妥',{silver:-2,karma:2,npc:{id:'mowenchen',relation:15},flags:['helpedTaoist']},'lesson'),choice('拜求仙法','未知',{check:{attr:'daoxin',difficulty:9},affinity:{wanderer:3},npc:{id:'mowenchen',relation:5}},'lesson',null,'老道用枯枝在泥里画出半个周天。','老道只笑你把长生看得太轻。'),choice('夺那盏灯','绝境',{check:{attr:'shafa',difficulty:16},item:'不灭残灯',sin:8,npc:{id:'mowenchen',relation:-30},flags:['robbedTaoist']},null,null,'灯竟没有抵抗，却在你识海里点起阴火。','枯枝一点，你昏睡三日，醒来时桥下已空。')]),
      node('lesson','雨中一问','assets/images/scenes/wandering-taoist.webp','老道问：“若百宗皆不收你，你还求不求道？”',[choice('天地不收，我自求之','未知',{daoxin:2,flags:['vowWanderer'],npc:{id:'mowenchen',relation:8}},null),choice('无门可入便罢了','稳妥',{health:4},null),choice('他们总会收我','冒险',{meili:1,shafa:1,flags:['proudVow']},null)])
    ]),
    chain('mortal_river','洪水夜舟','mortal',[9,9],20,99,[
      node('start','洪水夜舟','assets/images/scenes/river-flood.webp','河堤决口，渡船上还困着十余人。你听见水下有不似鱼类的低鸣。',[choice('驾小舟救人','凶险',{check:{attr:'shenfa',difficulty:12},health:-10,karma:4,meili:1,rootHint:{shui:2},flags:['riverRescue']},'dragon',null,'你借浪头三进三出，最后一人上岸时小舟才碎。','水下黑影撞翻小舟，你喝下半河冷水才爬上岸。'),choice('加固河堤','冒险',{check:{attr:'tipo',difficulty:11},gengu:1,tipo:1,karma:2},'dragon'),choice('保全自己','稳妥',{health:3,karma:-2},null)]),
      node('dragon','水下鳞光','assets/images/scenes/river-flood.webp','洪峰退去，一片冰冷鳞片留在泥中，握住它时水声忽然远去。',[choice('贴身收藏','未知',{item:'蛟鳞',rootHint:{shui:3,ice:1},flags:['dragonScale']},null),choice('交给县衙换赏','稳妥',{silver:16},null),choice('投入河中','稳妥',{karma:3,qiyun:1},null)])
    ]),
    chain('mortal_assembly','百宗问仙','assembly',[10,10],100,99,[
      node('start','仙门来时','assets/images/scenes/flying-boats.webp','第二十岁那日，云海裂开，百艘飞舟越过青石村。十年倒计时归零。',[choice('登山赴会','未知',{flags:['assemblyArrived']},'arrival')], 'assembly','wind'),
      node('arrival','万人登山','assets/images/scenes/sect-assembly.webp','凡人如潮涌向问仙台。你在人群中看见旧识，也看见九座高台上的仙门长老。',[choice('昂首入场','冒险',{daoxin:1},'root_test'),choice('观察考官','稳妥',{shenshi:1},'root_test'),choice('寻找旧识','稳妥',{meili:1},'root_test')], 'assembly','crowd'),
      node('root_test','测灵石鸣','assets/images/scenes/spirit-stone-test.webp','你的手落在测灵石上。十年经历在石中化作风、火、雷与水的暗纹。',[choice('引气入石','未知',{action:'revealRoot'},'aptitude')], 'assembly','thunder'),
      node('aptitude','三关问骨','assets/images/scenes/sect-exam.webp','根骨碑、问心阶与百兵台依次亮起。每一道光都在计算你过去十年的选择。',[choice('以最强一面应试','冒险',{action:'scoreAssembly'},'verdict'),choice('守拙求稳','稳妥',{action:'scoreAssembly',assemblySafe:2},'verdict')], 'assembly','impact'),
      node('verdict','仙门裁定','assets/images/scenes/sect-assembly.webp','九座高台沉默片刻。你的根骨、灵根、伤势、修为、亲和与旧日因果都将在此刻结算。',[choice('静候仙缘','未知',{action:'showInvites'},null)], 'assembly','gong')
    ])
  ];

  const CULTIVATION_CHAINS = [
    chain('peach_chain','桃源残玉','cultivation',[20,260],8,5,[
      node('start','雾里桃香','assets/images/scenes/peach-grove.webp','闭关归途中，山雾里飘来不合时节的桃香。',[choice('循香而去','冒险',{check:{attr:'qiyun',difficulty:10}},'fruit'),choice('远处观察','稳妥',{shenshi:1},'fruit'),choice('绕道离开','稳妥',{health:3},null)]),
      node('fruit','仙桃满枝','assets/images/scenes/peach-grove.webp','桃枝不见叶，只结着七枚泛光的果实，树下却没有脚印。',[choice('摘一枚','冒险',{lifespan:12,item:'仙桃'},'snake'),choice('寻找主人','稳妥',{karma:2,npc:{id:'shenqingshuang',relation:3}},'snake'),choice('继续深入','凶险',{cultivation:25},'snake')]),
      node('snake','赤鳞妖蛇','assets/images/scenes/beast-attack.webp','赤鳞妖蛇从树冠垂下，腹下压着另一块半月残玉。',[choice('正面斩蛇','凶险',{check:{attr:'shafa',difficulty:14},health:-14,cultivation:35,item:'神秘残玉·右'},'jade',null,'妖蛇伏诛，两块残玉在掌中同时发热。','蛇毒渗入经脉，你只得舍弃果实。'),choice('引蛇离开','冒险',{check:{attr:'shenfa',difficulty:13},item:'神秘残玉·右'},'jade'),choice('以神识探查','冒险',{check:{attr:'shenshi',difficulty:13},skill:'御兽残篇'},'jade'),choice('立即逃走','稳妥',{health:2},null)]),
      node('jade','因果回响','assets/images/scenes/cliff-cave.webp','半月残玉严丝合缝。你想起少年时崖下那具无名枯骨。',[choice('合并残玉','未知',{item:'上古洞府钥',flags:['jadeComplete'],future:{yearOffset:50,eventId:'ancient_cave'}},null)],'mystic','treasure')
    ]),
    chain('sword_rival','问剑同途','cultivation',[20,220],9,3,[
      node('start','问剑台','assets/images/scenes/tournament.webp','顾长歌提剑拦在台前：“道友，这十年你可曾荒废？”',[choice('全力一战','凶险',{check:{attr:'wuxing',difficulty:13},health:-10,cultivation:28,npc:{id:'guchangge',relation:5}},'after'),choice('点到为止','冒险',{check:{attr:'daoxin',difficulty:11},npc:{id:'guchangge',relation:10},cultivation:16},'after'),choice('拒绝比试','稳妥',{npc:{id:'guchangge',relation:-4}},null)],'battle','sword'),
      node('after','剑痕未冷','assets/images/scenes/tournament.webp','剑痕交错，胜负之外，你们都看见了彼此十年来的变化。',[choice('邀他论道','稳妥',{wuxing:1,npc:{id:'guchangge',relation:8}},null),choice('索要彩头','冒险',{spiritStones:18,npc:{id:'guchangge',relation:-3}},null),choice('记下他的破绽','未知',{skill:'破招式',flags:['knowsGuWeakness']},null)])
    ]),
    chain('merchant_return','铜铃入雾','cultivation',[30,300],8,6,[
      node('start','雾中铜铃','assets/images/scenes/merchant-cart.webp','无人牵引的木车驶出浓雾。车上的沈万山比当年从容许多。',[choice('叙旧','稳妥',{action:'merchantRelation'},'shop'),choice('只谈生意','稳妥',{spiritStones:-5},'shop'),choice('试探货源','冒险',{check:{attr:'shenshi',difficulty:12},item:'黑市情报'},'shop')]),
      node('shop','万宝木车','assets/images/scenes/merchant-cart.webp','丹药、残卷与法宝随铜铃声浮出木箱，价格会记得你当年的选择。',[choice('购买延寿丹','稳妥',{cost:{spiritStones:35},lifespan:16,item:'延寿丹'},null),choice('购买护心符','稳妥',{cost:{spiritStones:22},item:'护心符',demon:-8},null),choice('购买残图','未知',{cost:{spiritStones:28},item:'青帝陵残图',flags:['tombIntel']},null),choice('暂不购买','稳妥',{},null)])
    ]),
    chain('companion_moon','月下同行','cultivation',[30,260],7,4,[
      node('start','月下药香','assets/images/scenes/moon-companion.webp','沈清霜在崖边替一只受伤灵鹤包扎。她抬头叫出“{name}”。',[choice('留下帮忙','稳妥',{karma:2,npc:{id:'shenqingshuang',relation:10}},'talk'),choice('赠她灵药','稳妥',{removeItem:'回春丹',npc:{id:'shenqingshuang',relation:15}},'talk'),choice('邀她同游秘境','冒险',{npc:{id:'shenqingshuang',relation:7},flags:['companionJourney']},'talk')],'npc','relation-up'),
      node('talk','月照双影','assets/images/scenes/moon-companion.webp','灵鹤振翅远去。她说修道越久，越难有人记得自己最初为何出发。',[choice('讲述凡尘旧事','稳妥',{daoxin:1,npc:{id:'shenqingshuang',relation:8},flags:['sharedPast']},'bond'),choice('只谈大道','稳妥',{wuxing:1,npc:{id:'shenqingshuang',relation:3}},null),choice('沉默陪伴','未知',{npc:{id:'shenqingshuang',relation:6}},null)]),
      node('bond','月下相问','assets/images/scenes/moon-companion.webp','许多共同经历之后，沈清霜问你：往后的百年，是并肩问道，还是各守本心？',[choice('愿结为道侣','未知',{npc:{id:'shenqingshuang',relation:18},flags:['partnerShen'],title:'月下同心'},null,{flag:'sharedPast'}),choice('仍做知己','稳妥',{npc:{id:'shenqingshuang',relation:8},flags:['trustedFriend']},null)])
    ]),
    chain('heart_demon','心湖照影','cultivation',[40,400],9,4,[
      node('start','心湖照影','assets/images/scenes/heart-demon.webp','闭关第七年，你在心湖看见另一个自己：它拥有你错过的所有机缘。',[choice('承认遗憾','冒险',{check:{attr:'daoxin',difficulty:14},demon:-12,daoxin:1},'truth'),choice('斩碎幻影','凶险',{check:{attr:'shafa',difficulty:16},demon:8,cultivation:28},'truth'),choice('追问它的道路','未知',{check:{attr:'wuxing',difficulty:15},skill:'抱元守一'},'truth')],'heart','heartbeat'),
      node('truth','镜中因果','assets/images/scenes/heart-demon.webp','幻影翻开你的命书，每一处旧选择都生出不同结局。',[choice('承担自己的选择','稳妥',{karma:1,demon:-8,flags:['facedDemon']},null),choice('撕去最痛的一页','冒险',{demon:-14,karma:-4},null),choice('让幻影留下','绝境',{cultivation:45,demon:18,flags:['demonCompanion']},null)])
    ]),
    chain('sect_mission','宗门悬令','cultivation',[20,400],12,2,[
      node('start','宗门悬令','assets/images/scenes/sect-gate.webp','山门悬令征集弟子处理边境妖患，赏赐足够支撑下一次突破。',[choice('独自接令','凶险',{check:{attr:'shafa',difficulty:14},health:-12,cultivation:32,spiritStones:24},'return'),choice('邀同门同行','冒险',{check:{attr:'meili',difficulty:11},cultivation:22,spiritStones:15},'return'),choice('留守修炼','稳妥',{cultivation:14},null)]),
      node('return','功过台前','assets/images/scenes/sect-gate.webp','任务背后牵涉凡人村落。执事只问妖兽是否已死，不问过程。',[choice('如实上报','稳妥',{reputation:4,karma:1},null),choice('夸大功劳','冒险',{reputation:7,sin:2,flags:['falseReport']},null),choice('替村民隐瞒','未知',{karma:3,reputation:-1,flags:['protectedVillage']},null)])
    ]),
    chain('black_market','灯下黑市','cultivation',[30,400],7,5,[
      node('start','幽都灯市','assets/images/scenes/black-market.webp','魏青萝撑着青伞从红灯下走出：“道友，正道买不到的，我这里都有。”',[choice('看魔功','凶险',{npc:{id:'weiqingluo',relation:4}},'goods'),choice('向宁无涯买情报','稳妥',{cost:{spiritStones:18},flags:['worldIntel'],npc:{id:'ningwuya',relation:5}},'goods'),choice('转身离开','稳妥',{daoxin:1},null)]),
      node('goods','伞下禁物','assets/images/scenes/black-market.webp','血色玉简、替死木偶与一枚跳动的黑心依次摆开。',[choice('血海魔功','绝境',{cost:{spiritStones:45},skill:'血海魔功',sin:8,demon:10,flags:['demonPath']},null),choice('替死傀儡','凶险',{cost:{spiritStones:60},item:'替死傀儡'},null),choice('只记价格','稳妥',{shenshi:1},null)])
    ]),
    chain('alchemy_fire','丹炉异火','cultivation',[20,380],8,4,[
      node('start','丹炉婴啼','assets/images/scenes/alchemy-fire.webp','废弃丹房里传来婴儿啼哭，炉缝却溢出青黑色火光。',[choice('立即开炉','凶险',{check:{attr:'qiyun',difficulty:15},health:-12,item:'造化金丹'},'spirit'),choice('控火炼化','冒险',{check:{attr:'shenshi',difficulty:13},affinity:{alchemy:2},skill:'离火丹法'},'spirit'),choice('远离丹房','稳妥',{health:4},null)]),
      node('spirit','丹灵问命','assets/images/scenes/alchemy-fire.webp','一团火焰化成幼童模样，问你要长生，还是要救它。',[choice('放丹灵自由','稳妥',{karma:4,item:'丹灵余烬',flags:['freedPillSpirit']},null),choice('将其炼成丹','绝境',{lifespan:24,sin:7,demon:8},null),choice('订下百年契约','未知',{skill:'丹灵契',future:{yearOffset:100,eventId:'pill_spirit_return'}},null)])
    ]),
    chain('body_legacy','山岳残魂','cultivation',[30,320],6,8,[
      node('start','断碑如山','assets/images/scenes/cliff-cave.webp','一块无字断碑压住山谷，石无极的残魂从裂缝中睁眼。',[choice('以肩扛碑','绝境',{check:{attr:'tipo',difficulty:18},tipo:2,skill:'九转金身',npc:{id:'shiwujie',relation:15}},'oath'),choice('以神识问碑','凶险',{check:{attr:'shenshi',difficulty:16},wuxing:1,npc:{id:'shiwujie',relation:5}},'oath'),choice('祭拜离开','稳妥',{karma:1},null)]),
      node('oath','体宗最后一问','assets/images/scenes/cliff-cave.webp','残魂问你，若肉身必朽，为何还要炼它。',[choice('为护住想护之人','稳妥',{daoxin:1,karma:2,flags:['bodyOath']},null),choice('为拳碎天门','冒险',{shafa:2,flags:['breakHeaven']},null),choice('只为活得更久','未知',{lifespan:8},null)])
    ]),
    chain('rain_karma','凡尘旱雨','cultivation',[30,360],9,4,[
      node('start','三年无雨','assets/images/scenes/river-flood.webp','山下三年无雨，凡人跪在宗门石阶外。施雨会耗去你数年修为。',[choice('散灵化雨','冒险',{cultivation:-18,karma:5,reputation:2},'after'),choice('带人开渠','冒险',{check:{attr:'tipo',difficulty:12},health:-8,karma:3},'after'),choice('仙凡有别','稳妥',{sin:2,daoxin:-1},null)]),
      node('after','万家灯火','assets/images/scenes/river-flood.webp','雨落下时，万家灯火从山脚一直亮到天边。',[choice('不留姓名','稳妥',{qiyun:1,title:'无名雨师'},null),choice('受百姓香火','未知',{reputation:5,karma:2,demon:2},null)])
    ]),
    chain('old_friend','旧友暮年','cultivation',[50,300],7,8,[
      node('start','凡尘来信','assets/images/scenes/humble-home.webp','一封辗转数十年的凡书送到山门，旧友已经垂暮。',[choice('回乡送别','稳妥',{cultivation:-12,daoxin:2,karma:2},'farewell'),choice('送去延寿丹','冒险',{removeItem:'延寿丹',karma:3},'farewell'),choice('斩断尘缘','凶险',{daoxin:1,demon:7,flags:['cutMortalTies']},null)]),
      node('farewell','故乡无旧屋','assets/images/scenes/humble-home.webp','村口老槐还在，旧屋却只剩半堵土墙。凡人一生，比一次闭关还短。',[choice('记下他们的名字','稳妥',{title:'青石故人',demon:-5},null),choice('将往事留在坟前','未知',{daoxin:2},null)])
    ]),
    chain('world_debate','道争大辩','cultivation',[40,420],8,5,[
      node('start','诸宗论道','assets/images/scenes/sect-assembly.webp','正魔两道在天台论因果，一言不合便可能拔剑。',[choice('主张护生','冒险',{check:{attr:'meili',difficulty:13},karma:3,reputation:4},'challenge'),choice('主张强者为尊','凶险',{check:{attr:'shafa',difficulty:14},shafa:1,sin:3},'challenge'),choice('只观不言','稳妥',{wuxing:1},'challenge')]),
      node('challenge','一言成敌','assets/images/scenes/tournament.webp','你的立场引来一位陌生修士当众挑战。',[choice('应战','凶险',{check:{attr:'daoxin',difficulty:15},health:-10,cultivation:30},null),choice('以理化解','冒险',{check:{attr:'wuxing',difficulty:14},reputation:3},null),choice('离席','稳妥',{reputation:-1},null)])
    ]),
    chain('secret_realm','石门三问','cultivation',[30,400],10,3,[
      node('start','无字石门','assets/images/scenes/cliff-cave.webp','秘境石门浮出十枚古篆，最亮的对应你最强命数，最暗的对应你未曾正视的弱处。',[choice('以最强命数叩门','冒险',{check:{mode:'highest',difficulty:14},cultivation:28},'inside'),choice('以最弱命数叩门','凶险',{check:{mode:'lowest',difficulty:11},allStat:1},'inside'),choice('只临摹古篆','稳妥',{wuxing:1},null)]),
      node('inside','门后灵潮','assets/images/scenes/mystic-realm.webp','门后灵潮洗过经脉，深处还传来法宝碰撞石壁的声音。',[choice('继续深入','凶险',{check:{attr:'qiyun',difficulty:16},item:'山河印',health:-12},null),choice('就地修炼','稳妥',{cultivation:32},null),choice('留下路标','稳妥',{karma:2,reputation:2},null)])
    ]),
    chain('sect_tournament','百年宗门大比','cultivation',[60,420],7,8,[
      node('start','钟鸣九响','assets/images/scenes/tournament.webp','百年大比开场，胜者可入祖师洞天。你的仇敌也在签表另一端。',[choice('稳扎稳打','冒险',{check:{attr:'daoxin',difficulty:15},cultivation:38,reputation:5},'final'),choice('专挑强者','凶险',{check:{attr:'shafa',difficulty:18},cultivation:55,health:-15},'final'),choice('见好就收','稳妥',{spiritStones:20,reputation:2},null)]),
      node('final','魁首之前','assets/images/scenes/tournament.webp','最后一战，对手的招式竟与你命书中的某一页完全相同。',[choice('破招取胜','凶险',{check:{attr:'wuxing',difficulty:18},skill:'一气化三清',title:'宗门魁首'},null),choice('以伤换胜','绝境',{check:{attr:'tipo',difficulty:19},health:-28,item:'祖师令'},null),choice('主动认输','稳妥',{daoxin:1},null)])
    ]),
    chain('blood_moon','血月灵脉','cultivation',[40,400],8,5,[
      node('start','血月魔修','assets/images/scenes/blood-moon.webp','血月当空，乌玄子邀你共享一座无人看守的灵脉。',[choice('联手夺脉','凶险',{check:{attr:'shafa',difficulty:17},cultivation:50,sin:6,npc:{id:'wuxuanzi',relation:6}},'betrayal'),choice('假意应允','绝境',{check:{attr:'shenshi',difficulty:18},item:'饮血魔刀',npc:{id:'wuxuanzi',relation:-15}},'betrayal'),choice('远遁千里','冒险',{check:{attr:'shenfa',difficulty:13},health:-6},null)]),
      node('betrayal','背月一刀','assets/images/scenes/blood-moon.webp','禁制开启的一瞬，乌玄子的影子先于本人向你出手。',[choice('早有准备','凶险',{check:{attr:'shenshi',difficulty:17},spiritStones:45,npc:{id:'wuxuanzi',relation:-25}},null,null,'你反扣杀阵，夺走半座灵脉。','魔修从背后刺穿护体灵光，你负伤逃出生天。'),choice('以命搏命','绝境',{check:{attr:'tipo',difficulty:20},health:-30,cultivation:70,sin:4},null),choice('舍财逃命','稳妥',{spiritStones:-25,health:-8},null)])
    ]),
    chain('weapon_soul','兵魂认主','cultivation',[30,420],8,4,[
      node('start','古兵低鸣','assets/images/scenes/weapon-treasure.webp','封兵谷里，数百残兵同时朝你最熟悉的兵器方向低鸣。',[choice('回应最强亲和','冒险',{check:{mode:'affinity',difficulty:14},item:'本命兵胚'},'forge'),choice('强取陌生兵器','凶险',{check:{attr:'shafa',difficulty:17},item:'逆命兵胚',demon:5},'forge'),choice('听其自然','稳妥',{wuxing:1},null)]),
      node('forge','十年磨一器','assets/images/scenes/weapon-treasure.webp','兵胚需要你的十年修为、三十灵石，或一段旧记忆才能开锋。',[choice('耗修为开锋','冒险',{cultivation:-30,item:'开锋本命器'},null),choice('耗灵石开锋','稳妥',{cost:{spiritStones:30},item:'开锋本命器'},null),choice('献一段记忆','未知',{demon:6,karma:-2,item:'忘情本命器'},null)])
    ]),
    chain('healing_years','十年养伤','cultivation',[20,420],11,2,[
      node('start','药庐听雨','assets/images/scenes/alchemy-fire.webp','旧伤在雨季复发。裴玄真说可以治，但你必须放弃本回合一半修炼。',[choice('彻底疗伤','稳妥',{cultivation:-12,health:30,npc:{id:'peixuanzhen',relation:5}},'lesson'),choice('压伤修炼','凶险',{cultivation:30,health:-15,flags:['chronicWound']},null),choice('自行炼药','冒险',{check:{attr:'shenshi',difficulty:12},health:18,affinity:{alchemy:2}},'lesson')]),
      node('lesson','药理无情','assets/images/scenes/alchemy-fire.webp','裴玄真让你在救一个陌生人和保住一炉稀世丹之间选择。',[choice('救人','稳妥',{karma:3,npc:{id:'peixuanzhen',relation:8}},null),choice('保丹','冒险',{item:'化劫丹',sin:2},null)])
    ]),
    chain('jade_echo','桃核再鸣','cultivation',[30,420],100,99,[
      node('start','旧物发热','assets/images/scenes/peach-grove.webp','行囊深处的桃核与半月残玉同时发热。少年时埋下的那段因果，终于沿着灵气找回了你。',[choice('循光而去','冒险',{check:{attr:'qiyun',difficulty:13},cultivation:24,npc:{id:'yezhiqiu',relation:5}},'memory'),choice('以神识追索','冒险',{check:{attr:'shenshi',difficulty:14},skill:'溯缘术'},'memory'),choice('封存旧物','稳妥',{demon:-3},null)],'mystic','treasure'),
      node('memory','桃树下的旧约','assets/images/scenes/peach-grove.webp','当年的白狐已化作守林灵兽。它没有索要回报，只把一条通往旧洞府的山路留给你。',[choice('记下山路','稳妥',{flags:['jadeRoadKnown'],future:{yearOffset:40,eventId:'ancient_cave'}},null),choice('替它守林十年','稳妥',{karma:4,qiyun:1},null)])
    ]),
    chain('ancient_cave','上古洞府','cultivation',[60,520],100,99,[
      node('start','残玉开门','assets/images/scenes/mystic-realm.webp','两块残玉在石门前合拢。洞府没有金碧辉煌，只有一条向地心延伸的无灯长阶。',[choice('举火下行','凶险',{check:{attr:'daoxin',difficulty:17},demon:4},'guardian'),choice('让残玉引路','冒险',{check:{attr:'qiyun',difficulty:15},cultivation:35},'guardian'),choice('止步门外','稳妥',{spiritStones:18},null)],'mystic','gong'),
      node('guardian','无名守洞人','assets/images/scenes/cliff-cave.webp','石像睁眼，问你取传承是为了长生、杀敌，还是把断掉的道继续传下去。',[choice('为续道统','冒险',{check:{attr:'daoxin',difficulty:18},item:'上古道印',karma:4},'inheritance'),choice('为求长生','凶险',{check:{attr:'gengu',difficulty:18},lifespan:28,demon:6},'inheritance'),choice('为胜尽仇敌','绝境',{check:{attr:'shafa',difficulty:21},skill:'裂天古诀',sin:8},'inheritance')]),
      node('inheritance','洞天认主','assets/images/scenes/ascension.webp','石阶尽头不是宝库，而是一方濒临崩塌的小洞天。它等待的从来不是盗宝者，而是继承人。',[choice('承担洞天因果','未知',{flags:['jadeComplete'],title:'上古道统继承者',cultivation:80},null),choice('只取一卷离开','稳妥',{skill:'太古归一篇'},null)])
    ]),
    chain('pill_spirit_return','丹灵百年之约','cultivation',[120,620],100,99,[
      node('start','炉火归来','assets/images/scenes/alchemy-fire.webp','百年前放入山河的那缕丹灵已经长大。它踏着青焰回来，问你是否还记得旧约。',[choice('如约开炉','冒险',{check:{attr:'shenshi',difficulty:17},lifespan:30,item:'百年丹心'},'farewell'),choice('请它救治故人','稳妥',{karma:5,npc:{id:'peixuanzhen',relation:8}},'farewell'),choice('强行拘炼','绝境',{check:{attr:'shafa',difficulty:21},lifespan:45,sin:12,demon:10},'farewell')],'mystic','pill'),
      node('farewell','一火一诺','assets/images/scenes/alchemy-fire.webp','丹灵在炉边留下一个火印。无论此行得失，这场跨越百年的约定终于有了结尾。',[choice('送它远行','稳妥',{karma:3,daoxin:1},null),choice('留它守炉','未知',{skill:'丹灵契·圆满',flags:['pillSpiritHome']},null)])
    ]),
    chain('fallback','十年静修','cultivation',[20,999],1,0,[
      node('start','松间静修','assets/hero.webp','这十年风波稍歇，你得以整理旧伤、旧债与旧日所得。',[choice('闭关吐纳','稳妥',{cultivation:18,demon:-3},null),choice('游历山河','冒险',{qiyun:1,spiritStones:8},null),choice('整理命书','稳妥',{daoxin:1,karma:1},null)])
    ],{unique:false})
  ];

  const WORLD_EVENTS = [
    {id:'starfall_world',title:'天外星陨',min:28,max:55,image:'assets/images/scenes/starfall.webp',visible:true,chain:'starfall_chain'},
    {id:'qingdi_tomb',title:'青帝陵寝',min:62,max:105,image:'assets/images/scenes/mystic-realm.webp',visible:true,chain:'tomb_chain'},
    {id:'blood_moon_world',title:'血月临世',min:36,max:88,image:'assets/images/scenes/blood-moon.webp',visible:true,chain:'blood_moon'},
    {id:'kunlun_ruins',title:'昆仑仙墟',min:110,max:190,image:'assets/images/scenes/ascension.webp',visible:false,chain:'kunlun_chain'},
    {id:'war_world',title:'正魔大战',min:75,max:145,image:'assets/images/scenes/sect-assembly.webp',visible:true,chain:'war_chain'}
  ];

  const EXTRA_WORLD_CHAINS = [
    chain('starfall_chain','天外星陨','world',[20,420],100,99,[node('start','星落天南','assets/images/scenes/starfall.webp','整片夜空被陨火照亮。各宗修士尚未赶到，星核却已开始熔化山石。',[choice('独占星核','绝境',{check:{attr:'tipo',difficulty:19},health:-22,item:'星核法宝',sin:5},'fallout'),choice('通知同道分宝','冒险',{check:{attr:'meili',difficulty:14},reputation:5,item:'星屑'},'fallout'),choice('等待火熄','稳妥',{item:'陨铁碎片'},'fallout')]),node('fallout','星火余烬','assets/images/scenes/starfall.webp','陨坑深处传来并非此界的呼吸声。',[choice('继续下潜','绝境',{check:{attr:'shenshi',difficulty:20},skill:'天外观想法',demon:8},null),choice('封印陨坑','稳妥',{karma:4,reputation:4},null)])]),
    chain('tomb_chain','青帝陵寝','world',[20,420],100,99,[node('start','帝陵开门','assets/images/scenes/mystic-realm.webp','青木巨门从地底升起，寿元与机缘的气息同时涌出。',[choice('携同伴入陵','凶险',{check:{attr:'meili',difficulty:16},item:'青帝木心',health:-14},'coffin'),choice('独闯主墓','绝境',{check:{attr:'qiyun',difficulty:21},lifespan:35,item:'仙器碎片'},'coffin'),choice('只搜外围','冒险',{spiritStones:35,item:'延寿丹'},null)]),node('coffin','木棺生枝','assets/images/scenes/mystic-realm.webp','主棺生出万千枝叶，每片叶子都写着一个人的余寿。',[choice('取自己之叶','未知',{lifespan:24,karma:-3},null),choice('不取人寿','稳妥',{daoxin:2,skill:'枯木逢春'},null)])]),
    chain('kunlun_chain','昆仑仙墟','world',[20,420],100,99,[node('start','天门倒悬','assets/images/scenes/ascension.webp','破碎天门倒悬云海，门后是早已消失的仙域一角。',[choice('踏入天门','绝境',{check:{attr:'daoxin',difficulty:23},item:'登仙令',cultivation:90},null),choice('搜寻仙器碎片','凶险',{check:{attr:'shenshi',difficulty:19},item:'仙器碎片',health:-18},null),choice('记下坐标','稳妥',{flags:['kunlunKnown'],wuxing:1},null)])]),
    chain('war_chain','正魔大战','world',[20,420],100,99,[node('start','山河战火','assets/images/scenes/blood-moon.webp','正魔大战席卷三州。你的宗门发下征召，旧友与仇敌都在名单上。',[choice('守护宗门','凶险',{check:{attr:'tipo',difficulty:18},health:-20,reputation:10,cultivation:55},'choice'),choice('趁乱夺宝','绝境',{check:{attr:'shenfa',difficulty:20},item:'战场古宝',sin:10},'choice'),choice('护送凡人','冒险',{check:{attr:'meili',difficulty:14},karma:8,title:'渡世真人'},'choice')]),node('choice','战后残阳','assets/images/scenes/blood-moon.webp','战火熄灭时，命书上已有熟悉名字变成灰色。',[choice('立碑记名','稳妥',{daoxin:2,demon:-8},null),choice('追杀余敌','凶险',{shafa:2,sin:4},null)])])
  ];

  const INNATE_TAGS = [
    {attr:'wuxing',at:15,name:'聪慧过人',desc:'可更早看见判定属性。'},
    {attr:'wuxing',at:20,name:'生而知之',desc:'参悟成功时额外获得功法线索。'},
    {attr:'tipo',at:20,name:'天生蛮体',desc:'肉身检定获得巨大优势，但交涉更难。'},
    {attr:'shafa',at:20,name:'天生杀胚',desc:'战斗收益提高，仇敌与业障风险也提高。'},
    {attr:'meili',at:20,name:'谪仙之姿',desc:'人物初始好感提高，也更易招来执念。'},
    {attr:'qiyun',at:20,name:'天命眷顾',desc:'极低概率事件权重提高，失去时反噬更重。'},
    {attr:'daoxin',at:20,name:'澄明道心',desc:'心魔增长减缓，可见部分隐藏选择。'}
  ];

  window.V2_DATA = {
    version:'2.0.0',ATTRS,PATHS,SECTS,ROOTS,REALMS,NPCS,INNATE_TAGS,
    MORTAL_CHAINS,CULTIVATION_CHAINS:[...CULTIVATION_CHAINS,...EXTRA_WORLD_CHAINS],WORLD_EVENTS,
    LEGACY:legacy,
    MUSIC:{home:'home',mortal:'mortal',assembly:'assembly',sect:'sect',explore:'explore',battle:'battle',mystic:'mystic',npc:'npc',heart:'heart',tribulation:'tribulation',death:'death',ascension:'ascension'}
  };
})();
